
public class BackpackSlot {
	private int x,y,w,h;
	
	public BackpackSlot(int x, int y, int w, int h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
	}
	
	/********************************************************************************
	* hasPoint()                                                                    *
	* tells if point is in bounds                                                   *
	*                                                                               *
	* Parameters:                                                                   *
	* int x                                                                         *
	* int y                                                                         *
	*                                                                               *
	* Return Type: boolean hasPoint                                                 *
	*                                                                               *
	* Test Cases: none                                                              *
	********************************************************************************/
	public boolean hasPoint(int x, int y) {
		if (x >= this.x &&
			x <= this.x + this.w &&
			y >= this.y &&
			y <= this.y + this.h)
		{
			return true;
		}
		else return false;
	}

	public int getX() {return this.x;}
	public int getY() {return this.y;}
	public int getW() {return this.w;}
	public int getH() {return this.h;}
}
