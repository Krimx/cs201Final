import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class DiffArea {
	private Hitbox hitbox;
	private double x, y, w, h;
	private int level;
	private Color color;
	
	public DiffArea(double x1, double y1, double x2, double y2, int level) {
		this.w = x2 - x1;
		this.h = y2 - y1;
		
		this.x = x1;
		this.y = y1;
		
		this.hitbox = new Hitbox(this.x, this.y, this.w, this.h);
		
		this.level = level;
		
		if (this.level == 1) color = new Color(0,0,0,0);
		if (this.level == 2) color = new Color(100,0,50,40);
		if (this.level == 3) color = new Color(200,0,0,40);
	}
	
	public DiffArea(double x, double y, double w, double h, int level, boolean widths) {
		this.w = w;
		this.h = h;
		
		this.x = x + w / 2 - 2.5;
		this.y = y + h / 2 - 2.5;
		
		this.hitbox = new Hitbox(this.x, this.y, this.w, this.h);
		
		this.level = level;
		
		if (this.level == 1) color = new Color(0,0,0,0);
		if (this.level == 2) color = new Color(100,0,50,40);
		if (this.level == 3) color = new Color(200,0,0,40);
	}
	
	public void render(Graphics g, int scrWidth, int scrHeight, int mult, Camera camera, Resources recs) {
		double scale = (double) (((double) (scrWidth) / (double) (mult)) * 10);
		
		int xOffset = scrWidth / 2;
		int yOffset = scrHeight / 2;
		
		int renderW = (int) (w * scale);
		int renderH = (int) (h * scale);
		
		int renderX = (int) ((x * scale) + xOffset - camera.getX() - ((double) renderW / 2.0));
		int renderY = (int) ((y * scale) + yOffset - camera.getY() - ((double) renderH / 2.0));
		
		boolean inFrame = false;
		if (renderX < scrWidth &&
			renderX + renderW > 0 &&
			renderY < scrHeight &&
			renderY + renderH > 0)
		{
			inFrame = true;
		}
		
		if (inFrame) {
			g.setColor(color);
			g.fillRect(renderX, renderY, renderW, renderH);
		}
	}
	
	public Hitbox getHitbox() {return this.hitbox;}
	public double getX() {return this.x;}
	public double getY() {return this.y;}
	public double getW() {return this.w;}
	public double getH() {return this.h;}
	public int getLvl() {return this.level;}
	public Color getColor() {return this.color;}
	
	public String toString() {
		String toOut = this.x + ", " + this.y + ", " + this.w + ", " + this.h + ", " + this.level;
		
		return toOut;
	}
}
