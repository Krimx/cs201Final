import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;
import java.util.Scanner;

public class Interactable {
	private double x, y, w,h, scale;
	private String type;
	private Hitbox hitbox;
	private boolean collidable;
	private ArrayList<Item> items;
	
	public Interactable(double x, double y, double scale, double w, double h, String type) {
		this.x = x * scale;
		this.y = y * scale;
		this.w = w;
		this.h = h;
		
		this.scale = scale;
		
		this.type = type;
		
		
		switch (type) {
			case "chest":
				this.collidable = true;
				break;
			case "healChest":
				this.collidable = true;
				break;
			case "extraction":
				this.collidable = false;
				break;
			default:
				this.collidable = false;
				break;
		}
		
		this.hitbox = new Hitbox(this.x, this.y , this.w, this.h);
		
		this.items = new ArrayList<Item>();
	}
	
	/********************************************************************************
	* render()                                                                      *
	* renders to jpanel                                                             *
	*                                                                               *
	* Parameters:                                                                   *
	* Graphics g                                                                    *
	* int scrWidth                                                                  *
	* int scrHeight                                                                 *
	* int mult                                                                      *
	* Camera camera                                                                 *
	* Resources recs                                                                *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void render(Graphics g, int scrWidth, int scrHeight, int mult, Camera camera, Resources recs) {
		double scale = (double) (((double) (scrWidth) / (double) (mult)) * 10);
		
		int xOffset = scrWidth / 2;
		int yOffset = scrHeight / 2;
		
		int renderW = (int) (w * scale);
		int renderH = (int) (h * scale);
		
		int renderX = (int) ((x * scale) + xOffset - camera.getX() - ((double) renderW / 2.0));
		int renderY = (int) ((y * scale) + yOffset - camera.getY() - ((double) renderH / 2.0));

		BufferedImage toRender = null;
		

		if (this.type.equals("healChest")) toRender = recs.healChest;
		if (this.type.equals("chest")) toRender = recs.chest;
		if (this.type.equals("extraction")) toRender = recs.extraction;
		
		Graphics2D g2d = (Graphics2D) (g);
		if (toRender == null) {
			g.setColor(Color.green);
			g.fillRect(renderX, renderY, renderW, renderH);
		}
		else {
			g2d.drawImage(toRender, renderX, renderY, renderW, renderH, null);
		}
		
		
		
		//g.fillRect(renderX, renderY, (int) renderW, (int) renderH);
	}
	
	/********************************************************************************
	* dropItems()                                                                   *
	* drops stored items to be picked up                                            *
	*                                                                               *
	* Parameters:                                                                   *
	* ArrayList<Item> dropped                                                       *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void dropItems(ArrayList<Item> dropped) {
		for (Item item : items) {
			double toX = this.x + ThreadLocalRandom.current().nextDouble(-3,3.1);
			double toY = this.y + ThreadLocalRandom.current().nextDouble(-3,3.1);
			Item toDrop = new Item(toX, toY, item.getType());
			
			if (item.getType().equals("heal")) toDrop.setHealAmount(item.getHealAmount());
			
			dropped.add(toDrop);
		}
	}
	
	public void rollChestItems() {
		if (this.type.equals("healChest")) {
			int amount = ThreadLocalRandom.current().nextInt(2,5);
			
			for (int i = 0; i < amount; i++) {
				items.add(new Item(0,0,"heal"));
			}
			
			for (Item item : this.items) {
				
				if (item.getType().equals("heal")) {
					item.setHealAmount(20);
				}
			}
		}
	}
	
	/********************************************************************************
	* restOfStuff()                                                                 *
	* used to determine stored items                                                *
	*                                                                               *
	* Parameters:                                                                   *
	* String rest                                                                   *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void restOfStuff(String rest) {
		Scanner reader = new Scanner(rest);
		if (this.type.equals("chest")) {
			while (reader.hasNext()) {
				String toType = reader.next();
				int chanceToAdd = Integer.valueOf(reader.next());
				int addable = ThreadLocalRandom.current().nextInt(1, chanceToAdd + 1);
				if (addable == 1) {
					items.add(new Item(0,0,toType));
				}
			}
		}
		
		for (Item item : items) {
			if (item.getType().equals("heal")) {
				item.setHealAmount(20);
			}
		}
	}
	
	public Hitbox getHitbox() {return this.hitbox;}
	public double getX() {return this.x;}
	public double getY() {return this.y;}
	public double getScale() {return this.scale;}
	public String getType() {return this.type;}
	public boolean getCollidable() {return this.collidable;}
}
