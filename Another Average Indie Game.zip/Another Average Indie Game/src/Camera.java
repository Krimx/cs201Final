
public class Camera {
	private int x,y, bound;
	private int xOffset, yOffset;
	private int shakeTime;
	
	public Camera(int x, int y) {
		this.x = x;
		this.y = y;
		bound = 100;
		this.xOffset = 0;
		this.yOffset = 0;
		this.shakeTime = 0;
	}
	
	public void setX(int x) {this.x = x;}
	public void setY(int y) {this.y = y;}

	public void addX(int toAdd) {this.x += toAdd;}
	public void addY(int toAdd) {this.y += toAdd;}
	
	public int getX() {return this.x + this.xOffset;}
	public int getY() {return this.y + this.xOffset;}
	public int getBound() {return this.bound;}
	
	/********************************************************************************
	* shake()                                                                       *
	* modifies offsets based of dt and whatnot to give impression of shaking        *
	*                                                                               *
	* Parameters:                                                                   *
	* int time                                                                      *
	* int intensity                                                                 *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void shake(int time, int intensity) {
		if (this.shakeTime < time) {
			this.shakeTime++;
			int divider = intensity / 2;
			
			int delta = this.shakeTime % intensity + 1;
			
			if (delta <= divider) {
				this.xOffset = delta;
				this.yOffset = delta;
			}
			else {
				this.xOffset = -delta + divider;
				this.yOffset = -delta + divider;
			}
		}
	}
	public void resetShake() {this.shakeTime = 0;}
}
