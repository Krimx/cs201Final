import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class Spell {
	private String type;
	private double x,y, w,h;
	private double direction;
	private double speed;
	private int duration;
	private Hitbox hitbox;
	private boolean hitSomething;
	private int damage;
	
	public Spell(String type, double x, double y, Mouse mouse, Player player, int scrX, int scrY, double damageMult) {
		this.type = type;
		this.x = x;
		this.y = y;
		this.w = 5;
		this.h = 5;
		
		
		this.speed = 2;
		this.duration = 60;
		
		
		
		this.hitSomething = false;
		this.damage = (int) (20.0 * damageMult);
		
		if (this.type.equals("fireball")) {
			this.damage = (int) (20.0 * damageMult);
			this.direction = getAngle(scrX, scrY, mouse.getX(), mouse.getY());
		}
		if (this.type.equals("rumble")) {
			this.damage = (int) (50.0 * damageMult);
			this.speed = 0;
			this.direction = 0;
		}
		if (this.type.equals("lob")) {
			this.damage = (int) (50 * damageMult);
			this.speed = 1.0;
			this.w = 2;
			this.h = 2;
			this.direction = getAngle(this.x, this.y, player.getX(), player.getY());
		}
		if (this.type.equals("dagger")) {
			this.damage = (int) (15.0 * damageMult);
			this.direction = getAngle(scrX, scrY, mouse.getX(), mouse.getY());
			this.speed = 3.0;
			this.w = 1;
			this.h = 1;
		}
		
		this.hitbox = new Hitbox(x, y, w, h);
	}
	
	/********************************************************************************
	* getAngle()                                                                    *
	* needed to know what direction spell may need to go                            *
	*                                                                               *
	* Parameters:                                                                   *
	* int x1                                                                        *
	* int y1                                                                        *
	* int x2                                                                        *
	* int y2                                                                        *
	*                                                                               *
	* Return Type: double angle                                                     *
	*                                                                               *
	* Test Cases: none                                                              *
	********************************************************************************/
	public double getAngle(int x1, int y1, int x2, int y2) {
		double form1 = (double) (x2 - x1);
		double form2 = (double) (y2 - y1);
		double angle = Math.atan2(form2, form1);
		
		return angle;
	}
	
	public double getAngle(double x1, double y1, double x2, double y2) {
		double form1 = (double) (x2 - x1);
		double form2 = (double) (y2 - y1);
		double angle = Math.atan2(form2, form1);
		
		return angle;
	}
	
	/********************************************************************************
	* update()                                                                      *
	* updates every tick                                                            *
	*                                                                               *
	* Parameters:                                                                   *
	* ArrayList<Enemy> enemies                                                      *
	* ArrayList<Particle> particles                                                 *
	* Screen scr                                                                    *
	* Resources recs                                                                *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void update(Player player, ArrayList<Enemy> enemies, ArrayList<Block> blocks, ArrayList<Particle> particles, Screen scr, Resources recs) {
		double finX, finY;
		finX = this.x + (speed * Math.cos(direction));
		finY = this.y + (speed * Math.sin(direction));
		
		this.x = finX;
		this.y = finY;

		this.hitbox.update(x, y, w, h);
		
		if (this.duration > 0) this.duration--;
		
		if (this.type.equals("fireball") || this.type.equals("dagger")) {
			for (int i = 0; i < enemies.size(); i++) {
				if (this.hitbox.isColliding(enemies.get(i).getHitbox())) this.hitSomething = true;
				
			}
		}
		
		if (this.type.equals("fireball") || this.type.equals("lob")) {
			for (int i = 0; i < blocks.size(); i++) {
				if (this.hitbox.isColliding(blocks.get(i).getHitbox())) this.hitSomething = true;
				
			}
		}
		if (this.type.equals("lob")) {
			if (this.hitbox.isColliding(player.getHitbox())) this.hitSomething = true;
		}
		
		if (this.type.equals("rumble")) this.hitSomething = true;
		
		if (this.hitSomething) {
			if (this.type.equals("fireball")) {
				for (int i = 0; i < enemies.size(); i++) {
					if (enemies.get(i).distance(this.x, this.y) <= 10) {
						enemies.get(i).damage(this.damage);
					}
				}
				Particle toAdd = new Particle(this.x, this.y, "explosion", scr, recs);
				particles.add(toAdd);
			}
			if (this.type.equals("lob")) {
				if (this.hitbox.isColliding(player.getHitbox())) {
					player.damage(this.damage);
				}
			}
			
			if (this.type.equals("rumble")) {
				for (int i = 0; i < enemies.size(); i++) {
					if (enemies.get(i).distance(this.x, this.y) <= 17) {
						enemies.get(i).damage(this.damage);
					}
				}
				particles.add(new Particle(this.x, this.y, "rumble", scr, recs));
			}
			if (this.type.equals("dagger")) {
				for (int i = 0; i < enemies.size(); i++) {
					if (enemies.get(i).getHitbox().isColliding(this.hitbox)) {
						enemies.get(i).damage(this.damage);
					}
				}
			}
		}
	}
	
	public double distance(double x1, double y1, double x2, double y2 ) {
		return Math.hypot(x2 - x1, y2 - y1);
	}
	
	/********************************************************************************
	* render()                                                                      *
	* renders to jpanel                                                             *
	*                                                                               *
	* Parameters:                                                                   *
	* Graphics g                                                                    *
	* int scrWidth                                                                  *
	* int scrHeight                                                                 *
	* int mult                                                                      *
	* Camera camera                                                                 *
	* Resources recs                                                                *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void render(Graphics g, int scrWidth, int scrHeight, int mult, Camera camera, Resources recs) {
		double scale = (double) (((double) (scrWidth) / (double) (mult)) * 10);
		
		int xOffset = scrWidth / 2;
		int yOffset = scrHeight / 2;
		
		int renderW = (int) (w * scale);
		int renderH = (int) (h * scale);
		
		int renderX = (int) ((x * scale) + xOffset - camera.getX() - ((double) renderW / 2.0));
		int renderY = (int) ((y * scale) + yOffset - camera.getY() - ((double) renderH / 2.0));
		
		BufferedImage toRender = null;
		
		if (this.type.equals("fireball")) {
			toRender = recs.fireball;
			g.drawImage(toRender, renderX, renderY, renderW, renderH, null);
		}
		if (this.type.equals("lob")) {
			g.setColor(Color.black);
			g.fillOval(renderX, renderY, renderW, renderH);
		}
		if (this.type.equals("dagger")) {
			g.setColor(Color.LIGHT_GRAY);
			g.fillRect(renderX, renderY, renderW, renderH);
		}
	}
	
	public int getDuration() {return this.duration;}
	public boolean getHit() {return this.hitSomething;}
}
