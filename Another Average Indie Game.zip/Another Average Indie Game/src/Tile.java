import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class Tile {
	private double x, y, w,h, scale;
	private String type;
	private int rot;
	
	private ArrayList<String> possibleInters;
	private int interChance;
	
	public Tile(double x, double y, double scale, String type, int rot) {
		this.x = x * scale;
		this.y = y * scale;
		this.w = scale;
		this.h = scale;
		
		this.scale = scale;
		
		this.type = type;
		
		this.rot = rot;
		
		this.possibleInters = new ArrayList<String>();
		this.interChance = 0;
	}
	
	public void addPossibleInter(String toAdd) {this.possibleInters.add(toAdd);}
	public void setInterChance(int chance) {this.interChance = chance;}
	
	/********************************************************************************
	* render()                                                                      *
	* renders to jpanel                                                             *
	*                                                                               *
	* Parameters:                                                                   *
	* Graphics g                                                                    *
	* Resources recs                                                                *
	* int scrWidth                                                                  *
	* int scrHeight                                                                 *
	* int mult                                                                      *
	* Camera camera                                                                 *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void render(Graphics g, int scrWidth, int scrHeight, int mult, Camera camera, Resources recs) {
		double scale = (double) (((double) (scrWidth) / (double) (mult)) * 10);
		
		int xOffset = scrWidth / 2;
		int yOffset = scrHeight / 2;
		
		int renderW = (int) (w * scale);
		int renderH = (int) (h * scale);
		
		int renderX = (int) ((x * scale) + xOffset - camera.getX() - ((double) renderW / 2.0));
		int renderY = (int) ((y * scale) + yOffset - camera.getY() - ((double) renderH / 2.0));
		
		boolean inFrame = false;
		if (renderX < scrWidth &&
			renderX + renderW > 0 &&
			renderY < scrHeight &&
			renderY + renderH > 0)
		{
			inFrame = true;
		}

		if (inFrame) {
			BufferedImage toRender = null;

			if (this.type.equals("clean")) toRender = recs.cleanTile;
			if (this.type.equals("cracked")) toRender = recs.crackedTile;
			if (this.type.equals("interact")) toRender = recs.interactTile;
			
			Graphics2D g2d = (Graphics2D) (g);
			
			g2d.rotate(Math.toRadians(rot * 90), renderX + (renderW / 2), renderY + (renderH / 2));
			g2d.drawImage(toRender, renderX, renderY, renderW, renderH, null);
			g2d.rotate(Math.toRadians(-rot * 90), renderX + (renderW / 2), renderY + (renderH / 2));
		}
	}
	
	public double getRenderX(Graphics g, int scrWidth, int scrHeight, int mult, Camera camera) {
		double scale = (double) (((double) (scrWidth) / (double) (mult)) * 10);
		
		int xOffset = scrWidth / 2;
		
		int renderW = (int) (w * scale);
		
		int renderX = (int) ((x * scale) + xOffset - camera.getX() - ((double) renderW / 2.0));
		
		return renderX;
	}
	
	public double getRenderY(Graphics g, int scrWidth, int scrHeight, int mult, Camera camera) {
		double scale = (double) (((double) (scrWidth) / (double) (mult)) * 10);
		
		int yOffset = scrHeight / 2;
		
		int renderH = (int) (h * scale);
		
		int renderY = (int) ((y * scale) + yOffset - camera.getY() - ((double) renderH / 2.0));
		
		return renderY;
	}
	
	public double distance(double x1, double y1, double x2, double y2 ) {
		return Math.hypot(x2 - x1, y2 - y1);
	}
	
	public boolean hasAdjBlock(ArrayList<Block> blocks) {
		boolean hasAdjBlock = false;
		for (Block block : blocks) {
			if (distance(this.x, this.y, block.getX(), block.getY()) <= 5) {
				hasAdjBlock = true;
			}
		}
		
		return hasAdjBlock;
	}
	
	//2.0 0.0 5.0 3.0 3.0 chest
	
	/*
	public void doInteractables(ArrayList<Block> blocks, ArrayList<Interactable> inters) {
		boolean canRoll = true;
		if (x == 0 && y == 0) canRoll = false;
		
		if (canRoll) {
			int doChest = ThreadLocalRandom.current().nextInt(1, chanceForChest + 1);
			
			if (doChest == chanceForChest) {
				inters.add(new Interactable(this.x / this.scale,this.y / this.scale,this.scale,3,3,"chest"));
			}
		}
		
	}
	*/
	
	public void doInteractables(ArrayList<Interactable> inters) {
		if (this.interChance > 0) {
			boolean doingInter = ThreadLocalRandom.current().nextInt(1, this.interChance + 1) == this.interChance;
			
			if (doingInter) {
				String toType = this.possibleInters.get(ThreadLocalRandom.current().nextInt(0, this.possibleInters.size()));
				
				inters.add(new Interactable(this.x / this.scale,this.y / this.scale,this.scale,3,3,toType));
			}
		}
	}

	public double getX() {return this.x / this.scale;}
	public double getY() {return this.y / this.scale;}
	public double getScale() {return this.scale;}
	public String getType() {return this.type;}
	public int getRot() {return this.rot;}
	
	public int getInterChance() {return this.interChance;}
	public String getPossibleInter(int n) {return this.possibleInters.get(n);}
}
