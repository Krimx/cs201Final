import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;

public class Player {
	private double x,y;
	private double w,h,bh;
	private double vx,vy;
	private double walkSpeed, runSpeed, workingSpeed, acc;
	private double nvx, nvy;
	private Hitbox hitbox, leftBox, rightBox, upBox, downBox;
	private boolean leftCol, rightCol, upCol, downCol;
	
	private BufferedImage sprite;
	private int animCtr;
	private String direction;
	
	private int maxMana, mana, manaCooldownTime, manaRegenTicks;
	private int manaCooldown, manaRegen;
	
	private String selectedSpell;
	private int rX, rY;
	private double itemPickupDistance;
	private int health, maxHealth;
	private int maxPackSize;
	
	private String lastDirection;
	
	private ArrayList<Item> inventory, backpack;
	
	private boolean dead, usedT1Health, usedT2Health, usedT3Health, usedT4Health, usedDamage1, usedDamage2, usedDamage3, usedMana1, usedMana2, usedMana3;
	
	private int damageTicks;
	private double damageMult, speedMult;
	
	private boolean hasRumble, hasDagger;
	
	private ArrayList<String> availableSpells = new ArrayList<String>();
	private int currentSpellIndex;
	private int spellEssence;
	
	public Player() {
		x = 0;
		y = 0;
		w = 4;
		h = 6;
		bh = 1;
		vx = 0;
		vy = 0;
		walkSpeed = 0.3;
		runSpeed = 0.6;
		acc = 1.0;
		damageTicks = 20;
		this.dead = false;
		
		leftCol = false;
		rightCol = false;
		upCol = false;
		downCol = false;
		this.damageMult = 1;
		this.speedMult = 1.0;
		
		hitbox = new Hitbox(x,y,w,bh);
		
		leftBox = new Hitbox(x - (w / 2) - 0.1,
				y - (bh / 2) + 0.1,
				0.1,
				bh - 0.2);
		
		rightBox = new Hitbox(x + (w / 2),
				y - (bh / 2) + 0.1,
				0.1,
				bh - 0.2);
		
		upBox = new Hitbox(x - (w / 2) + 0.1,
				y - (bh / 2) - 0.1,
				w - 0.2,
				0.1
				);
		
		downBox = new Hitbox(x - (w / 2) + 0.1,
				y + (bh / 2),
				w - 0.2,
				0.1
				);
		
		animCtr = 0;
		sprite = null;
		direction = "still";
		selectedSpell = "fireball";
		
		this.rX = 0;
		this.rY = 0;

		this.inventory = new ArrayList<Item>();
		this.backpack = new ArrayList<Item>();
		
		lastDirection = "down";
		
		this.spellEssence = 0;
		Scanner reader = null;
		try {
			reader = new Scanner(new File("SaveData/" + "save1" + ".data"));
			this.spellEssence = Integer.valueOf(reader.nextLine());
		}
		catch(Exception e) {}
	}
	
	/********************************************************************************
	* initStats()                                                                   *
	* initializes stats at the start of a round                                     *
	*                                                                               *
	* Parameters:                                                                   *
	* String fileName                                                               *
	* Resources recs                                                                *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void initStats(String fileName, Resources recs, boolean invStuff) {
		boolean doingInv = false;
		boolean doingPack = false;
		
		Scanner reader = null;
		try {
			reader = new Scanner(new File("SaveData/" + fileName + ".data"));
		}
		catch(Exception e) {}

		maxMana = 100;
		manaCooldownTime = 60;
		manaRegenTicks = 2;
		manaRegen = 1;
		
		mana = maxMana;
		manaCooldown = manaCooldownTime;
		
		itemPickupDistance = 4;
		
		maxHealth = 100;
		health = maxHealth;
		
		maxPackSize = 20;
		
		if (invStuff) {
			while (reader.hasNextLine()) {
				String line = reader.nextLine();
				Scanner lr = new Scanner(line);
				
				if (doingPack && !line.equals("}")) {
					String type = lr.next();
					Item toAdd = new Item(0,0,type);
					toAdd.setImage(recs);
					this.backpack.add(toAdd);
				}
				
				if (doingInv && !line.equals("}")) {
					String type = lr.next();
					Item toAdd = new Item(0,0,type);
					toAdd.setImage(recs);
					this.inventory.add(toAdd);
				}
				
				if (line.equals("Backpack {")) doingPack = true;
				if (doingPack && line.equals("}")) doingPack = false;

				if (line.equals("Inventory {")) doingInv = true;
				if (doingInv && line.equals("}")) doingInv = false;
			}
		}

		usedT1Health = false;
		usedT2Health = false;
		usedT3Health = false;
		usedT4Health = false;
		usedDamage1 = false;
		usedDamage2 = false;
		usedDamage3 = false;
		usedMana1 = false;
		usedMana2 = false;
		usedMana3 = false;

		hasRumble = false;
		hasDagger = false;
		
		this.availableSpells.clear();
		this.availableSpells.add("fireball");
		currentSpellIndex = 0;
	}
	
	/********************************************************************************
	* saveStats()                                                                   *
	* saves stats to file                                                           *
	*                                                                               *
	* Parameters:                                                                   *
	* PrintWriter writer                                                            *
	* boolean withPack                                                              *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void saveStats(PrintWriter writer, boolean withPack) {
		writer.println(this.spellEssence);
		writer.println("Backpack {");
		if (withPack) {
			for (Item item : this.backpack) {
				writer.println(item);
			}
		}
		writer.println("}");
		
		writer.println("Inventory {");
		for (Item item : this.inventory) {
			writer.println(item);
		}
		writer.println("}");
	}
	
	/********************************************************************************
	* updateHitboxes()                                                              *
	* updates all of the hitboxes because I do that multiple times                  *
	*                                                                               *
	* Parameters: none                                                              *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void updateHitboxes() {
		hitbox.update(x,y,w,bh);
		
		leftBox.update(x - (w / 2) - 0.1,
				y + (h / 2),
				0.1,
				bh - 0.5);
		
		rightBox.update(x + (w / 2),
				y + (h / 2),
				0.1,
				bh - 0.5);
		
		upBox.update(x,
				y - (bh / 2) - 0.1 + (h / 2),
				w - 0.5,
				0.1
				);
		
		downBox.update(x,
				y + (bh / 2) + (h / 2),
				w - 0.5,
				0.1
				);
	}
	
	public void resetDirs() {
		leftCol = false;
		rightCol = false;
		upCol = false;
		downCol = false;
	}
	
	public void normalize() {
		double mag = Math.sqrt((vx * vx) + (vy * vy));
		
		nvx = (vx / mag) * workingSpeed * speedMult;
		nvy = (vy / mag) * workingSpeed * speedMult;
		
		nvy = round(nvy);
		nvx = round(nvx);
	}
	
	public double round(double in) {
		return Math.round(in*100)/100.0;
	}
	
	public void clamp(double value, double max, double min) {
		if (value > max) value = max;
		if (value < min) value = min;
	}
	
	public double distance(double x1, double y1, double x2, double y2 ) {
		return Math.hypot(x2 - x1, y2 - y1);
	}
	
	public void collision(ArrayList<Block> blocks, ArrayList<Interactable> inters) {
		for (Block block : blocks) {
			if (this.rightBox.isColliding(block.getHitbox())) rightCol = true;
			if (this.leftBox.isColliding(block.getHitbox())) leftCol = true;
			if (this.upBox.isColliding(block.getHitbox())) upCol = true;
			if (this.downBox.isColliding(block.getHitbox())) downCol = true;
		}
		
		for (Interactable inter : inters) {
			if (this.rightBox.isColliding(inter.getHitbox()) && inter.getCollidable()) rightCol = true;
			if (this.leftBox.isColliding(inter.getHitbox()) && inter.getCollidable()) leftCol = true;
			if (this.upBox.isColliding(inter.getHitbox()) && inter.getCollidable()) upCol = true;
			if (this.downBox.isColliding(inter.getHitbox()) && inter.getCollidable()) downCol = true;
		}
	}
	
	public double getAngle(double x1, double y1, double x2, double y2) {
		double form1 = (double) (x2 - x1);
		double form2 = (double) (y2 - y1);
		double angle = Math.atan2(form2, form1);
		
		return angle;
	}
	
	/********************************************************************************
	* update()                                                                      *
	* runs every tick; should be self-explanatory                                   *
	*                                                                               *
	* Parameters:                                                                   *
	* Keyboard keys                                                                 *
	* Mouse mouse                                                                   *
	* ArrayList<Block> blocks                                                       *
	* ArrayList<Interactable> inters                                                *
	* ArrayList<Item> items                                                         *
	* ArrayList<Enemy> enemies                                                      *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void update(Keyboard keys, Mouse mouse, ArrayList<Block> blocks, ArrayList<Interactable> inters, ArrayList<Item> items, ArrayList<Enemy> enemies) {
		boolean left = false, right = false, up = false, down = false;
		if (keys.W()) {
			up = true;
			lastDirection = "up";
		}
		else up = false;
		if (keys.S()) {
			down = true;
			lastDirection = "down";
		}
		else down = false;
		if (keys.A()) {
			left = true;
			lastDirection = "left";
		}
		else left = false;
		if (keys.D()) {
			right = true;
			lastDirection = "right";
		}
		else right = false;
		
		if (keys.LSHIFT()) workingSpeed = runSpeed;
		if (!keys.LSHIFT()) {
			workingSpeed = walkSpeed;
		}
		
		if (up && down) vy = 0;
		if (!up && !down) vy = 0;
		if (up) if (vy < workingSpeed) vy += acc;
		if (down) if (vy > -workingSpeed) vy -= acc;
		
		if (left && right) vx = 0;
		if (!left && !right) vx = 0;
		if (left) if (vx > -workingSpeed) vx -= acc;
		if (right) if (vx < workingSpeed) vx += acc;

		clamp(vx, workingSpeed, -workingSpeed);
		clamp(vy, workingSpeed, -workingSpeed);

		vy = round(vy);
		vx = round(vx);
		
		normalize();
		
		resetDirs();
		updateHitboxes();
		
		if (this.damageTicks < 40) this.damageTicks++;
		
		for (Enemy enemy : enemies) {
			if (enemy.getType().equals("spurt")) {
				if (this.hitbox.isColliding(enemy.getHitbox())) {
					this.nvx = 0;
					this.nvy = 0;
					
					double newAngle = getAngle(enemy.getX(), enemy.getY(), this.x, this.y);
					
					this.nvx = (4 * Math.cos(newAngle));
					this.nvy = (4 * Math.sin(newAngle));
					
					if (damageTicks == 40) {
						this.health -= enemy.getDamage();
						this.damageTicks = 0;
					}
				}
			}
		}
		
		for (double i = 0; i < Math.abs(nvx); i += 0.1) {
			resetDirs();
			
			collision(blocks, inters);
			
			if (nvx > 0 && !this.rightCol) {
				x += 0.1;
				direction = "right";
			}
			if (nvx < 0 && !this.leftCol) {
				x -= 0.1;
				direction = "left";
			}

			//if (nvx > 0) x += 0.1;
			//if (nvx < 0) x -= 0.1;
			
			x = round(x);
			
			updateHitboxes();
		}
		
		resetDirs();
		for (double i = 0; i < Math.abs(nvy); i += 0.1) {
			resetDirs();
			
			collision(blocks, inters);
			
			if (nvy > 0 && !this.upCol) {
				y -= 0.1;
				direction = "up";
			}
			if (nvy < 0 && !this.downCol) {
				y += 0.1;
				direction = "down";
			}
			
			//if (nvy > 0) y -= 0.1;
			//if (nvy < 0) y += 0.1;
			
			y = round(y);
			
			updateHitboxes();
		}
		
		if (nvx == 0 && nvy == 0) direction = "still";
		
		if (this.health <= 0) die();

		if (keys.K1TYPED()) this.selectedSpell = "fireball";
		if (keys.K2TYPED() && this.hasRumble) this.selectedSpell = "rumble";
		if (keys.K3TYPED() && this.hasDagger) this.selectedSpell = "dagger";
		
		if (keys.LEFTTYPED()) {
			if (this.currentSpellIndex == 0) this.currentSpellIndex = this.availableSpells.size() - 1;
			else this.currentSpellIndex--;
			this.selectedSpell = this.availableSpells.get(this.currentSpellIndex);
		}
		if (keys.RIGHTTYPED()) {
			if (this.currentSpellIndex == this.availableSpells.size() - 1) this.currentSpellIndex = 0;
			else this.currentSpellIndex++;
			this.selectedSpell = this.availableSpells.get(this.currentSpellIndex);
		}
	}
	
	public void die() {
		this.backpack.clear();
		this.dead = true;
	}
	
	public boolean useItem(int i) {
		if (this.backpack.get(i).getType().equals("healthUp") && !this.usedT1Health) {
			this.maxHealth = 100 + this.backpack.get(i).getMaxHealthBoost();
			this.health = this.maxHealth;
			this.usedT1Health = true;
			return true;
		}
		if (this.backpack.get(i).getType().equals("healthUp2") && !this.usedT2Health) {
			this.maxHealth = 100 + this.backpack.get(i).getMaxHealthBoost();
			this.health = this.maxHealth;
			this.usedT2Health = true;
			return true;
		}
		if (this.backpack.get(i).getType().equals("healthUp3") && !this.usedT3Health) {
			this.maxHealth = 100 + this.backpack.get(i).getMaxHealthBoost();
			this.health = this.maxHealth;
			this.usedT3Health = true;
			return true;
		}
		if (this.backpack.get(i).getType().equals("healthUp4") && !this.usedT4Health) {
			this.maxHealth = 100 + this.backpack.get(i).getMaxHealthBoost();
			this.health = this.maxHealth;
			this.usedT4Health = true;
			return true;
		}
		if (this.backpack.get(i).getType().equals("damageUp1") && !this.usedDamage1) {
			this.damageMult = this.damageMult * this.backpack.get(i).getDamageBoost();
			this.usedDamage1 = true;
			return true;
		}
		if (this.backpack.get(i).getType().equals("damageUp2") && !this.usedDamage2) {
			this.damageMult = this.damageMult * this.backpack.get(i).getDamageBoost();
			this.usedDamage2 = true;
			return true;
		}
		if (this.backpack.get(i).getType().equals("damageUp3") && !this.usedDamage3) {
			this.damageMult = this.damageMult * this.backpack.get(i).getDamageBoost();
			this.usedDamage3 = true;
			return true;
		}
		if (this.backpack.get(i).getType().equals("manaUp1") && !this.usedMana1) {
			this.maxMana = 100 + this.backpack.get(i).getManaBoost();
			this.mana = this.maxMana;
			this.usedMana1 = true;
			return true;
		}
		if (this.backpack.get(i).getType().equals("manaUp2") && !this.usedMana2) {
			this.maxMana = 100 + this.backpack.get(i).getManaBoost();
			this.mana = this.maxMana;
			this.usedMana2 = true;
			return true;
		}
		if (this.backpack.get(i).getType().equals("manaUp3") && !this.usedMana3) {
			this.maxMana = 100 + this.backpack.get(i).getManaBoost();
			this.mana = this.maxMana;
			this.usedMana3 = true;
			return true;
		}
		if (this.backpack.get(i).getType().equals("rumbleTome") && !this.hasRumble) {
			this.hasRumble = true;
			this.availableSpells.add("rumble");
			return true;
		}
		if (this.backpack.get(i).getType().equals("daggerTome") && !this.hasRumble) {
			this.hasDagger = true;
			this.availableSpells.add("dagger");
			return true;
		}
		return false;
	}
	
	public int interact(Keyboard keys, ArrayList<Interactable> inters, ArrayList<Item> items, Resources recs) {
		int outCondition = -1;
		
		if (keys.ETYPED()) {
			for (int i = 0; i < inters.size(); i++) {
				if (distance(this.x, this.y, inters.get(i).getX(), inters.get(i).getY()) <= 7.5) {
					if (inters.get(i).getType().equals("chest")) {
						inters.get(i).dropItems(items);
						inters.remove(i);

						recs.bling.setFramePosition(0);
						recs.bling.start();
							
						break;
					}
					if (inters.get(i).getType().equals("healChest")) {
						inters.get(i).dropItems(items);
						inters.remove(i);

						recs.bling.setFramePosition(0);
						recs.bling.start();
						
						break;
					}
					if (inters.get(i).getType().equals("extraction")) {
						outCondition = 1;
						break;
					}
					
				}
			}
		}
		
		return outCondition;
	}
	
	public void pickupItems(ArrayList<Item> items, Resources recs) {
		for (int i = 0; i < items.size(); i++) {
			if (distance(this.x, this.y, items.get(i).getX(), items.get(i).getY()) <= this.itemPickupDistance) {
				if (items.get(i).getType().equals("heal")) {
					if (this.health < this.maxHealth) {
						this.health += items.get(i).getHealAmount();
						
						if (this.health < this.maxHealth) {
							recs.healSound.setFramePosition(0);
							recs.healSound.start();
						}
						
						if (this.health > this.maxHealth) {
							this.health = this.maxHealth;
						}
						items.remove(i);
					}
				}
				else if (items.get(i).getType().equals("essence")) {
					this.spellEssence++;
					items.remove(i);
				}
				else {
					if (this.backpack.size() < this.maxPackSize) {
						recs.itemPickup.setFramePosition(0);
						recs.itemPickup.start();
						
						this.backpack.add(items.get(i).clone());
						items.remove(i);
					}
				}
			}
		}
	}
	
	public void doAbilities(Keyboard keys, Mouse mouse, ArrayList<Spell> spells, boolean hoveringOverPack, ArrayList<Enemy> enemies) {
		if (!hoveringOverPack) {
			if (mouse.LEFTCLICKED()) {
				manaCooldown = 0;
				if (selectedSpell.equals("fireball")) {
					if (mana >= 30) {
						spells.add(new Spell("fireball", this.x, this.y, mouse, null, this.rX, this.rY, this.damageMult));
						mana -= 30;
					}
				}
				if (selectedSpell.equals("rumble")) {
					if (mana >= 40) {
						spells.add(new Spell("rumble", this.x, this.y, mouse, null, this.rX, this.rY, this.damageMult));
						mana -= 40;
					}
				}
				if (selectedSpell.equals("dagger")) {
					if (mana >= 25) {
						spells.add(new Spell("dagger", this.x, this.y, mouse, null, this.rX, this.rY, this.damageMult));
						mana -= 25;
					}
				}
			}
		}
		
	}
	
	public void regenMana() {
		if (manaCooldown == manaCooldownTime) {
			if (manaRegen < manaRegenTicks) manaRegen++;
			if (manaRegen == manaRegenTicks) {
				manaRegen = 0;
				if (mana < maxMana) mana++;
			}
		}
		
		if (manaCooldown < manaCooldownTime) manaCooldown++;
	}
	
	public void updateCamera(int scrWidth, int scrHeight, int mult, Camera camera) {
		double scale = (double) (((double) (scrWidth) / (double) (mult)) * 10);
		
		int xOffset = scrWidth / 2;
		int yOffset = scrHeight / 2;
		
		int renderW = (int) (w * scale);
		int renderH = (int) (h * scale);
		
		int renderX = (int) ((x * scale) + xOffset - camera.getX());
		int renderY = (int) ((y * scale) + yOffset - camera.getY());
		
		int borderRight = scrWidth - camera.getBound();
		int borderLeft = camera.getBound();
		int borderUp = camera.getBound();
		int borderDown = scrHeight - camera.getBound();

		if (renderX >= borderRight && nvx > 0) camera.addX((int) (this.workingSpeed * scale));
		if (renderX <= borderLeft && nvx < 0) camera.addX((int) (-this.workingSpeed * scale));
		if (renderY <= borderUp && nvy > 0) camera.addY((int) (-this.workingSpeed * scale));
		if (renderY >= borderDown && nvy < 0) camera.addY((int) (this.workingSpeed * scale));
		
		if (renderX >= borderRight && nvx == 0) camera.addX(1);
		if (renderX <= borderLeft && nvx == 0) camera.addX(-1);
		if (renderY <= borderUp && nvy == 0) camera.addY(-1);
		if (renderY >= borderDown && nvy == 0) camera.addY(1);
	}
	
	/********************************************************************************
	* render()                                                                      *
	* renders things to the jpanel                                                  *
	*                                                                               *
	* Parameters:                                                                   *
	* Graphics g                                                                    *
	* int scrWidth                                                                  *
	* int scrHeight                                                                 *
	* int mult                                                                      *
	* Camera camera                                                                 *
	* Resources recs                                                                *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void render(Graphics g, int scrWidth, int scrHeight, int mult, Camera camera, Resources recs) {
		double scale = (double) (((double) (scrWidth) / (double) (mult)) * 10);
		
		int xOffset = scrWidth / 2;
		int yOffset = scrHeight / 2;
		
		int renderW = (int) (w * scale);
		int renderH = (int) (h * scale);
		
		int renderX = (int) ((x * scale) + xOffset - camera.getX() - ((double) renderW / 2.0));
		int renderY = (int) ((y * scale) + yOffset - camera.getY() - ((double) renderH / 2.0));
		
		this.rX = (int) (renderX + ((double) renderW / 2.0));
		this.rY = (int) (renderY + ((double) renderH / 2.0));

		//g.setColor(Color.green);

		if (animCtr > 0 && animCtr <= 50) {
			if (direction.equals("still")) sprite = recs.charSprite1;
			if (direction.equals("down")) sprite = recs.charSprite1;
			if (direction.equals("up")) sprite = recs.charBack1;
			if (direction.equals("left")) sprite = recs.charLeft1;
			if (direction.equals("right")) sprite = recs.charRight1;
		}
		if (animCtr > 50 && animCtr <= 100) {
			if (direction.equals("still")) sprite = recs.charSprite2;
			if (direction.equals("down")) sprite = recs.charSprite2;
			if (direction.equals("up")) sprite = recs.charBack2;
			if (direction.equals("left")) sprite = recs.charLeft2;
			if (direction.equals("right")) sprite = recs.charRight2;
		}
		

		g.drawImage(recs.playerShadow, renderX, (int) (renderY + (renderH * (15.0 / 18.0))), (int) renderW, (int) (renderH * (6.0 / 18.0)), null);
		
		g.drawImage(sprite, renderX, renderY, (int) renderW, (int) renderH, null);
		//g.fillRect(renderX, renderY, (int) renderW, (int) renderH);
		
		//this.hitbox.render(g, scrWidth, scrHeight, camera);
	}
	
	public void renderUI(Graphics g, Font font, int scrWidth, int scrHeight, Resources recs) {
		g.setFont(font);
		g.setColor(Color.white);
		g.drawString("Health: " + health + " / " + maxHealth, 10, 30);
		g.drawString("Mana: " + mana + " / " + maxMana, 10, 80);
		g.drawString("Essence: " + this.spellEssence, 10, 130);
		
		//Drawing stat bars
		
		int barLength = 150;
		int statBarLength = barLength - 4;
		
		g.setColor(Color.gray);
		g.fillRect(10, 35, barLength, 20);
		g.setColor(Color.black);
		g.fillRect(12, 37, statBarLength, 16);

		g.setColor(Color.gray);
		g.fillRect(10, 85, barLength, 20);
		g.setColor(Color.black);
		g.fillRect(12, 87, statBarLength, 16);
		
		//Health Bar
		g.setColor(new Color(247, 74, 74));
		int healthLength = (int) ((double)statBarLength * ((double) this.health / (double) this.maxHealth));
		g.fillRect(12, 37, healthLength, 8);
		g.setColor(new Color(200, 74, 74));
		g.fillRect(12, 45, healthLength, 8);
		
		//Mana Bar
		g.setColor(new Color(75, 230, 247));
		int manaLength = (int) ((double)statBarLength * ((double) this.mana / (double) this.maxMana));
		g.fillRect(12, 87, manaLength, 8);
		g.setColor(new Color(68, 214, 230));
		g.fillRect(12, 95, manaLength, 8);
		
		displaySelectedSpell(g, scrWidth, scrHeight, recs);
	}
	
	public void displaySelectedSpell(Graphics g, int scrWidth, int scrHeight, Resources recs) {
		double heightRat = 8.0/10.0;
		double widthRat = 21.0/10.0;
		int rH = (int) ((double) Main.scrWidth * (1.0/14.0));
		int rX = Main.scrWidth - (int) ((double) Main.scrWidth * (1.0/6.0));
		
		BufferedImage toOut = recs.fireballSpell;
		if (this.selectedSpell.equals("rumble")) toOut = recs.rumbleSpell;
		if (this.selectedSpell.equals("dagger")) toOut = recs.daggerSpell;
		
		g.drawImage(recs.spellBook, rX, 10, (int) (rH * widthRat), rH, null);
		g.drawImage(toOut, (int) (rX + ((double) (rH * widthRat) * (1.0/21.0))), (int) (10 + (rH * (1.0/10.0))), (int) (rH * heightRat), (int) (rH * heightRat), null);
	}
	
	/********************************************************************************
	* animate()                                                                     *
	* updates rendered sprite based on animation ticks                              *
	*                                                                               *
	* Parameters: none                                                              *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void animate() {
		animCtr++;
		
		if (animCtr > 100) animCtr = 0;
	}
	
	public void damage(int damage) {
		this.health -= damage;
	}
	
	public void setPos(int x, int y) {this.x = x; this.y = y;}
	public void setHealth(int health) {this.health = health;}
	public void  setUsedT1Health(boolean in) {this.usedT1Health = in;}
	public void setMaxHealth(int maxHealth) {this.maxHealth = maxHealth;}
	public void setDead(boolean dead) {this.dead = dead;}
	public void setDamageMult(double mult) {this.damageMult = mult;}
	public void setSpeedMult(double mult) {this.speedMult = mult;}
	public void setMaxMana(int maxMana) {this.maxMana = maxMana;}
	public void setManaCooldownTime(int time) {this.manaCooldownTime = time;}
	public void setManaRegenTicks(int ticks) {this.manaRegenTicks = ticks;}
	public void setManaRegenAmount(int amount) {this.manaRegen = amount;}
	public void setItemPickupDistance(double distance) {this.itemPickupDistance = distance;}
	public void addEssence(int in) {this.spellEssence += in;}
	
	public Hitbox getHitbox() {return hitbox;}
	public Hitbox getLeftBox() {return leftBox;}
	public Hitbox getRightBox() {return rightBox;}
	public Hitbox getUpBox() {return upBox;}
	public Hitbox getDownBox() {return downBox;}
	
	public int getMaxPackSize() {return this.maxPackSize;}
	public double getX() {return this.x;}
	public double getY() {return this.y;}
	public ArrayList<Item> getPack() {return this.backpack;}
	public ArrayList<Item> getInv() {return this.inventory;}
	public String getLastDir() {return this.lastDirection;}
	public int getMaxHealth() {return this.maxHealth;}
	public boolean getDead() {return this.dead;}
	public int getSpellEssence() {return this.spellEssence;}
}