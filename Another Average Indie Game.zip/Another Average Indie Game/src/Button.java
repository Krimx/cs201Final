import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class Button {
	private int x, y, w,h;
	private String label;
	private Font labelFont;
	private Color color, hoverColor;
	private boolean hovering;
	
	public Button(int x, int y, int w, int h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		
		this.labelFont = new Font("Helvetica", Font.PLAIN, 12);
		this.color = new Color(109,83,119);
		this.hoverColor = new Color(65,49,73);
		this.hovering = false;
	}
	
	public Button(int x, int y, int w, int h, String label) {
		this(x,y,w,h);
		this.label = label;
	}
	
	/********************************************************************************
	* hasPoint()                                                                    *
	* determines if point is in bounds                                              *
	*                                                                               *
	* Parameters:                                                                   *
	* int x                                                                         *
	* int y                                                                         *
	*                                                                               *
	* Return Type: boolean hasPoint                                                 *
	*                                                                               *
	* Test Cases: none                                                              *
	********************************************************************************/
	public boolean hasPoint(int x, int y) {
		if (x >= this.x &&
			x <= this.x + this.w &&
			y >= this.y &&
			y <= this.y + this.h)
		{
			return true;
		}
		else return false;
	}
	
	/********************************************************************************
	* hasMouse()                                                                    *
	* tells if mouse is hovering                                                    *
	*                                                                               *
	* Parameters:                                                                   *
	* Mouse mouse                                                                   *
	*                                                                               *
	* Return Type: boolean hasMouse                                                 *
	*                                                                               *
	* Test Cases: none                                                              *
	********************************************************************************/
	public boolean hasMouse(Mouse mouse) {
		if (mouse.getX() >= this.x &&
				mouse.getX() <= this.x + this.w &&
				mouse.getY() >= this.y &&
				mouse.getY() <= this.y + this.h)
			{
				this.hovering = true;
				return true;
			}
			else {
				this.hovering = false;
				return false;
			}
	}
	
	/********************************************************************************
	* render()                                                                      *
	* draws to jpanel                                                               *
	*                                                                               *
	* Parameters:                                                                   *
	* Graphics g                                                                    *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void render(Graphics g) {
		
		if (this.hovering) g.setColor(this.hoverColor);
		else g.setColor(this.color);
		g.fillRect(x, y, w, h);

		g.setColor(Color.white);
		g.setFont(this.labelFont);
		
		int fontHeight = this.labelFont.getSize();
		
		g.drawString(this.label, this.x + 5, this.y + fontHeight * 2);
	}
	
	public void setLabelFont(Font font) {this.labelFont = font;}
	public void setPos(int x, int y) {
		this.x = x;
		this.y = y;
	}
}
