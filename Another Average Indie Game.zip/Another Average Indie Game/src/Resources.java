import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.print.attribute.standard.Media;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;
import javax.swing.JLabel;
import java.net.URL;

import javax.swing.Icon;
import javax.swing.ImageIcon;

public class Resources {
	public BufferedImage soloBlock, cornerBlock, edgeBlock, longEdgeBlock, longCornerBlock, longCorner2, inCornerLeft, inCornerRight, outCornerLeft, outCornerRight, topEdge;
	public BufferedImage cleanTile, crackedTile, interactTile;
	public BufferedImage charSprite1, charSprite2;
	public BufferedImage charLeft1, charLeft2;
	public BufferedImage charRight1, charRight2;
	public BufferedImage charBack1, charBack2;
	public BufferedImage playerShadow;
	public BufferedImage chest, extraction, healChest;
	public BufferedImage AOSprite;
	public BufferedImage spellBook, fireball, fireballSpell, rumbleSpell, rumbleTome, daggerSpell, daggerTome, truffle, pinGem;
	
	public BufferedImage healthItem, faceSigil, healthUp, healthUp2, healthUp3, healthUp4;
	public BufferedImage damageUp1, damageUp2, damageUp3;
	public BufferedImage blackHeart, manaUp1, manaUp2, manaUp3;
	public BufferedImage essence;
	public BufferedImage ooze;
	
	public BufferedImage rightClickIcon, leftClickIcon, packIcon, invIcon;
	
	public Clip bling, itemPickup, healSound;
	
	public BufferedImage spurtRight, spurtLeft, spurtFront, spurtBack, puegotSquish, puegotStretch, sloanFront;
	
	public BufferedImage leftArrow;
	
	public JLabel testGif;
	
	public Resources() {
		try {
			soloBlock = ImageIO.read(new File("Recs/soloBlock.png"));
			cornerBlock = ImageIO.read(new File("Recs/cornerBlock.png"));
			edgeBlock = ImageIO.read(new File("Recs/edgeBlock.png"));
			longEdgeBlock = ImageIO.read(new File("Recs/longEdge.png"));
			longCornerBlock = ImageIO.read(new File("Recs/longCorner.png"));
			longCorner2 = ImageIO.read(new File("Recs/longCorner2.png"));
			inCornerLeft = ImageIO.read(new File("Recs/inCornerLeft.png"));
			inCornerRight = ImageIO.read(new File("Recs/inCornerRight.png"));
			outCornerLeft = ImageIO.read(new File("Recs/outCornerLeft.png"));
			outCornerRight = ImageIO.read(new File("Recs/outCornerRight.png"));
			topEdge = ImageIO.read(new File("Recs/topEdge.png"));

			cleanTile = ImageIO.read(new File("Recs/cleanTile.png"));
			crackedTile = ImageIO.read(new File("Recs/crackedTile.png"));
			interactTile = ImageIO.read(new File("Recs/interactTile.png"));

			charSprite1 = ImageIO.read(new File("Recs/char1.png"));
			charSprite2 = ImageIO.read(new File("Recs/char2.png"));

			charLeft1 = ImageIO.read(new File("Recs/charLeft1.png"));
			charLeft2 = ImageIO.read(new File("Recs/charLeft2.png"));

			charRight1 = ImageIO.read(new File("Recs/charRight1.png"));
			charRight2 = ImageIO.read(new File("Recs/charRight2.png"));

			charBack1 = ImageIO.read(new File("Recs/charBack1.png"));
			charBack2 = ImageIO.read(new File("Recs/charBack2.png"));

			playerShadow = ImageIO.read(new File("Recs/playerShadow.png"));

			healthItem = ImageIO.read(new File("Recs/healthItem.png"));
			faceSigil = ImageIO.read(new File("Recs/faceSigil.png"));
			blackHeart = ImageIO.read(new File("Recs/blackHeart.png"));
			healthUp = ImageIO.read(new File("Recs/healthUp.png"));
			healthUp2 = ImageIO.read(new File("Recs/healthUp2.png"));
			healthUp3 = ImageIO.read(new File("Recs/healthUp3.png"));
			healthUp4 = ImageIO.read(new File("Recs/healthUp4.png"));
			damageUp1 = ImageIO.read(new File("Recs/t1DamageBoost.png"));
			damageUp2 = ImageIO.read(new File("Recs/t2DamageBoost.png"));
			damageUp3 = ImageIO.read(new File("Recs/t3DamageBoost.png"));
			manaUp1 = ImageIO.read(new File("Recs/t1Mana.png"));
			manaUp2 = ImageIO.read(new File("Recs/t2Mana.png"));
			manaUp3 = ImageIO.read(new File("Recs/t3Mana.png"));

			chest = ImageIO.read(new File("Recs/chest.png"));
			healChest = ImageIO.read(new File("Recs/healChest.png"));
			extraction = ImageIO.read(new File("Recs/extraction.png"));

			rightClickIcon = ImageIO.read(new File("Recs/rightClickMouse.png"));
			leftClickIcon = ImageIO.read(new File("Recs/leftClickMouse.png"));
			packIcon = ImageIO.read(new File("Recs/packIcon.png"));
			invIcon = ImageIO.read(new File("Recs/invIcon.png"));

			AOSprite = ImageIO.read(new File("Recs/AOSprite.png"));

			spurtRight = ImageIO.read(new File("Recs/spurtRight.png"));
			spurtLeft = ImageIO.read(new File("Recs/spurtLeft.png"));
			spurtFront = ImageIO.read(new File("Recs/spurtFront.png"));
			spurtBack = ImageIO.read(new File("Recs/spurtBack.png"));

			fireball = ImageIO.read(new File("Recs/fireball.png"));
			fireballSpell = ImageIO.read(new File("Recs/fireballSpell.png"));
			rumbleSpell = ImageIO.read(new File("Recs/rumbleSpell.png"));

			spellBook = ImageIO.read(new File("Recs/spellBook.png"));
			
			testGif = new JLabel(new ImageIcon("./Recs/Gifs/testGif.gif"));

			leftArrow = ImageIO.read(new File("Recs/leftArrow7x7.png"));

			puegotSquish = ImageIO.read(new File("Recs/puegotSquish.png"));
			puegotStretch = ImageIO.read(new File("Recs/puegotStretch.png"));

			rumbleTome = ImageIO.read(new File("Recs/rumbleTome.png"));

			essence = ImageIO.read(new File("Recs/essence.png"));

			sloanFront = ImageIO.read(new File("Recs/sloanFront.png"));

			ooze = ImageIO.read(new File("Recs/ooze.png"));
			daggerSpell = ImageIO.read(new File("Recs/daggerSpell.png"));
			daggerTome = ImageIO.read(new File("Recs/daggerTome.png"));
			truffle = ImageIO.read(new File("Recs/truffle.png"));
			pinGem = ImageIO.read(new File("Recs/pinGem.png"));
			
			/*
			 * Ok so funny story
			 * When I was using Clip, whenever I started a clip, there would be like a solid second of delay
			 * So I spent like an hour searching for a solution and nothing really worked
			 * I found a forum that suggested using libraries that I was familiar with in a different way
			 * So I tried it out
			 * And for some reason, when I do the code below, the delay goes away
			 * Idk whats going on here but it works in my favor so womp womp
			 */
			
			//Credit to m13r on StackOverflow for this block
			File blingFile = new File("Recs/sfx/bling.wav");
			AudioInputStream stream = AudioSystem.getAudioInputStream(blingFile);
			AudioFormat format = stream.getFormat();
			DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
			SourceDataLine sourceLine = (SourceDataLine) AudioSystem.getLine(info);
			sourceLine.open(format);
			sourceLine.start();
			

			bling = AudioSystem.getClip();
			bling.open(AudioSystem.getAudioInputStream(new File("Recs/sfx/bling.wav")));
			
			itemPickup = AudioSystem.getClip();
			itemPickup.open(AudioSystem.getAudioInputStream(new File("Recs/sfx/itemPickup.wav")));
			
			healSound = AudioSystem.getClip();
			healSound.open(AudioSystem.getAudioInputStream(new File("Recs/sfx/heal.wav")));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/********************************************************************************
	* testGif()                                                                     *
	* loads and sends a gif to the jpanel; same for every similar method            *
	*                                                                               *
	* Parameters:                                                                   *
	* int w                                                                         *
	* int h                                                                         *
	*                                                                               *
	* Return Type: JLabel                                                           *
	*                                                                               *
	* Test Cases: none                                                              *
	********************************************************************************/
	public JLabel testGif(int w, int h) {
		JLabel toOut = new JLabel();
		ImageIcon icon = new ImageIcon(new ImageIcon("./Recs/Gifs/testGif.gif").getImage().getScaledInstance(w, h, Image.SCALE_DEFAULT));
		toOut.setIcon(icon);
		return toOut;
	}
	

	
	public JLabel explosionGif(int w, int h) {
		JLabel toOut = new JLabel();
		ImageIcon icon = new ImageIcon(new ImageIcon("./Recs/Gifs/explosion.gif").getImage().getScaledInstance(w, h, Image.SCALE_DEFAULT));
		toOut.setIcon(icon);
		return toOut;
	}
}
