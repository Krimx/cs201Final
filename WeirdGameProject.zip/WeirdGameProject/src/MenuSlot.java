import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Scanner;

public class MenuSlot {
	private Item item;
	private int x,y,w;
	private boolean hovering = false;
	
	public MenuSlot(Item item) {
		this.item = item;
		this.x = 0;
		this.y = 0;
		this.w = 0;
	}

	public void setX(int x) {this.x = x;}
	public void setY(int y) {this.y = y;}
	public void setW(int w) {this.w = w;}
	
	
	public Item getItem() {return this.item;}
	
	/********************************************************************************
	* render()                                                                      *
	* renders to jpanel                                                             *
	*                                                                               *
	* Parameters:                                                                   *
	* Graphics g                                                                    *
	* int margin                                                                    *
	* Resources recs                                                                *
	* int scroll                                                                    *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void render(Graphics g, int margin, Resources recs, int scroll) {
		g.setColor(new Color(200,100,200,40));

		if (this.hovering) {
			g.setColor(new Color(255,100,255,60));
			g.setColor(Color.white);
			int startX = x + (margin * 2) - w;
			g.drawImage(recs.leftClickIcon, startX, y + margin - scroll, 14,18, null);
			g.drawString("Switch", startX + 16, y + margin - scroll + 18);
			g.drawImage(recs.rightClickIcon, startX, y + margin + 30 - scroll, 14,18, null);
			g.drawString("Craft", startX + 16, y + margin + 18 + 30 - scroll);
			
			ArrayList<String> flavorText = new ArrayList<String>();
			Scanner lore = new Scanner(item.getLore());
			String toAdd = "";
			boolean added = false;
			while (lore.hasNext()) {
				String bit = lore.next();
				if (bit.equals("[]")) {
					flavorText.add(toAdd);
					added = true;
					toAdd = "";
				}
				else {
					toAdd += bit + " ";
					added = false;
				}
			}
			if (!added) flavorText.add(toAdd);
			
			for (int j = 0; j < flavorText.size(); j++) {
				int toY = y + (j * 25) + (4 * margin);
				g.drawString(flavorText.get(j), startX + (w * 2), toY - scroll);
			}
		}
		g.fillRect(x, y - scroll, w,w);
		g.drawImage(this.item.getImage(), x + margin, y + margin - scroll, w - (margin * 2), w - (margin * 2), null);
		
	}
	
	/********************************************************************************
	* hasMouse()                                                                    *
	* checks if mouse is hovering over region                                       *
	*                                                                               *
	* Parameters:                                                                   *
	* Mouse mouse                                                                   *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public boolean hasMouse(Mouse mouse) {
		if (mouse.getX() >= this.x &&
			mouse.getX() <= this.x + this.w &&
			mouse.getY() >= this.y &&
			mouse.getY() <= this.y + this.w)
		{
			this.hovering = true;
			return true;
		}
		else {
			this.hovering = false;
			return false;
		}
	}
	
	public boolean hasPoint(int x, int y) {
		if (x >= this.x &&
			x <= this.x + this.w &&
			y >= this.y &&
			y <= this.y + this.w)
		{
			this.hovering = true;
			return true;
		}
		else {
			this.hovering = false;
			return false;
		}
	}
}
