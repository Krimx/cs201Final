import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class CraftingRecipe {
	private ArrayList<String> inputs = new ArrayList<String>();
	private String output;
	
	private BufferedImage outSprite;
	private ArrayList<BufferedImage> inSprites = new ArrayList<BufferedImage>();
	private int reqEssence;
	
	public CraftingRecipe(String output, Resources recs) {
		this.output = output;
		if (output.equals("healthUp")) {
			this.outSprite = recs.healthUp;
			inputs.add("faceSigil");
			inSprites.add(recs.faceSigil);
			inputs.add("faceSigil");
			inSprites.add(recs.faceSigil);
		}
		if (output.equals("healthUp2")) {
			this.outSprite = recs.healthUp2;
			inputs.add("healthUp");
			inSprites.add(recs.healthUp);
			inputs.add("healthUp");
			inSprites.add(recs.healthUp);
		}
		if (output.equals("healthUp3")) {
			this.outSprite = recs.healthUp3;
			inputs.add("healthUp2");
			inSprites.add(recs.healthUp2);
			inputs.add("healthUp2");
			inSprites.add(recs.healthUp2);
			inputs.add("healthUp2");
			inSprites.add(recs.healthUp2);
		}
		if (output.equals("healthUp4")) {
			this.outSprite = recs.healthUp4;
			inputs.add("healthUp3");
			inSprites.add(recs.healthUp3);
			inputs.add("healthUp3");
			inSprites.add(recs.healthUp3);
			inputs.add("healthUp3");
			inSprites.add(recs.healthUp3);
			inputs.add("healthUp3");
			inSprites.add(recs.healthUp3);
		}
		if (output.equals("damageUp1")) {
			this.outSprite = recs.damageUp1;
			inputs.add("pinGem");
			inSprites.add(recs.pinGem);
			inputs.add("pinGem");
			inSprites.add(recs.pinGem);
		}
		if (output.equals("damageUp2")) {
			this.outSprite = recs.damageUp2;
			inputs.add("damageUp1");
			inSprites.add(recs.damageUp1);
			inputs.add("damageUp1");
			inSprites.add(recs.damageUp1);
		}
		if (output.equals("damageUp3")) {
			this.outSprite = recs.damageUp3;
			inputs.add("damageUp2");
			inSprites.add(recs.damageUp2);
			inputs.add("damageUp2");
			inSprites.add(recs.damageUp2);
			inputs.add("damageUp2");
			inSprites.add(recs.damageUp2);
		}
		if (output.equals("manaUp1")) {
			this.outSprite = recs.manaUp1;
			inputs.add("blackHeart");
			inSprites.add(recs.blackHeart);
			inputs.add("blackHeart");
			inSprites.add(recs.blackHeart);
		}
		if (output.equals("manaUp2")) {
			this.outSprite = recs.manaUp2;
			inputs.add("manaUp1");
			inSprites.add(recs.manaUp1);
			inputs.add("manaUp1");
			inSprites.add(recs.manaUp1);
		}
		if (output.equals("manaUp3")) {
			this.outSprite = recs.manaUp3;
			inputs.add("manaUp2");
			inSprites.add(recs.manaUp2);
			inputs.add("manaUp2");
			inSprites.add(recs.manaUp2);
			inputs.add("manaUp2");
			inSprites.add(recs.manaUp2);
		}
		if (output.equals("rumbleTome")) {
			this.outSprite = recs.rumbleTome;
			this.reqEssence = 10;
			inputs.add("truffle");
			inSprites.add(recs.truffle);
		}
		if (output.equals("daggerTome")) {
			this.outSprite = recs.daggerTome;
			this.reqEssence = 20;
			inputs.add("ooze");
			inSprites.add(recs.ooze);
		}
	}

	public ArrayList<String> getInputs() {return this.inputs;}
	public String getOutput() {return this.output;}
	public ArrayList<BufferedImage> getInSprites() {return this.inSprites;}
	public BufferedImage getOutSprite() {return this.outSprite;}
	public int getReqEssence() {return this.reqEssence;}
}
