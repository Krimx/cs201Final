import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JLabel;

public class Particle {
	private double x, y;
	private int w,h;
	private String type;
	private int life;
	private JLabel sprite;
	private boolean added;
	
	public Particle(double x, double y, String type, Screen scr, Resources recs) {
		this.x = x;
		this.y = y;
		this.type = type;
		
		if (this.type.equals("explosion")) {
			this.w = 10;
			this.h = 10;
			life = 60;
			sprite = recs.explosionGif(this.w * 10, this.h * 10);
		}
		if (this.type.equals("rumble")) {
			this.w = 1;
			this.h = 1;
			life = 60;
		}
		added = false;
	}
	
	/********************************************************************************
	* update()                                                                      *
	* runs every tick                                                               *
	*                                                                               *
	* Parameters: none                                                              *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void update() {
		this.life--;
		
		if (this.type.equals("rumble")) {
			this.w++;
			this.h++;
		}
	}
	
	/********************************************************************************
	* render()                                                                      *
	* renders to jpanel                                                             *
	*                                                                               *
	* Parameters:                                                                   *
	* Graphics g                                                                    *
	* int scrWidth                                                                  *
	* int scrHeight                                                                 *
	* int mult                                                                      *
	* Camera camera                                                                 *
	* Resources recs                                                                *
	* Screen scr                                                                    *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void Render(Graphics g, int scrWidth, int scrHeight, int mult, Camera camera, Resources recs, Screen scr) {
		double scale = (double) (((double) (scrWidth) / (double) (mult)) * 10);
		
		int xOffset = scrWidth / 2;
		int yOffset = scrHeight / 2;
		
		int renderW = (int) (this.w * 10);
		int renderH = (int) (this.h * 10);
		
		int renderX = (int) ((x * scale) + xOffset - camera.getX() - ((double) renderW / 2.0));
		int renderY = (int) ((y * scale) + yOffset - camera.getY() - ((double) renderH / 2.0));
		
		if (this.type.equals("explosion")) {
			sprite.setSize(renderW, renderH);
			sprite.setBounds(renderX, renderY, renderW, renderH);
			if (!added) {
				scr.add(sprite);
				added = true;
			}
		}
		if (this.type.equals("rumble")) {
			g.setColor(new Color(0,200,100, (int) ((double) (this.life / 60.0) * 100.0)));
			g.fillOval(renderX, renderY, renderW, renderH);
		}
		
	}
	
	public int getLife() {return this.life;}
	public double getX() {return this.x;}
	public double getY() {return this.y;}
	public String getType() {return this.type;}
	
	public JLabel getSprite() {return this.sprite;}
}
