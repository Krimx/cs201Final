import java.util.ArrayList;

public class EnemySpawner {
	private double x, y;
	private int[][] locs = new int[10][2];
	private Enemy toSpawn;
	private int cooldown, dCooldown;
	private double spawnDistance;
	private boolean canSpawn;
	private int spawnTimes;
	
	public EnemySpawner (double x, double y, double scale, int[][] locs, Enemy toSpawn, int cooldown, double spawnDistance) {
		this.x = x * scale;
		this.y = y * scale;
		this.locs = locs;
		this.toSpawn = toSpawn;
		this.cooldown = cooldown;
		dCooldown = cooldown;
		this.spawnDistance = spawnDistance;
		this.canSpawn = true;
		this.spawnTimes = -1;
	}
	public EnemySpawner (double x, double y, double scale, int[][] locs, Enemy toSpawn, int cooldown, double spawnDistance, int spawnTimes) {
		this.x = x * scale;
		this.y = y * scale;
		this.locs = locs;
		this.toSpawn = toSpawn;
		this.cooldown = cooldown;
		dCooldown = cooldown;
		this.spawnDistance = spawnDistance;
		this.canSpawn = true;
		this.spawnTimes = spawnTimes;
	}
	
	/********************************************************************************
	* spawn()                                                                       *
	* spawns enemies when enemies are needed to be spawned                          *
	*                                                                               *
	* Parameters:                                                                   *
	* ArrayList<Enemy> enemies                                                      *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void spawn(ArrayList<Enemy> enemies) {
		this.canSpawn = true;
		for (Enemy enemy : enemies) {
			if (enemy.distance(this.x,  this.y) <= 3 && enemy.getType().equals("puegot")) {
				this.canSpawn = false;
			}
		}
		if (this.canSpawn) {
			if (this.dCooldown > 0) this.dCooldown--;
			
			if (this.dCooldown == 0) {
				this.dCooldown = this.cooldown;
				
				if (this.spawnTimes < 0) {
					for (int[] i : locs) {
						Enemy toAdd = new Enemy(toSpawn.getType(), toSpawn.getLevel(), this.x + i[0], this.y + i[1], 1, toSpawn.getTag());
						enemies.add(toAdd);
					}
				}
				else {
					if (this.spawnTimes > 0) {
						for (int[] i : locs) {
							Enemy toAdd = new Enemy(toSpawn.getType(), toSpawn.getLevel(), this.x + i[0], this.y + i[1], 1, toSpawn.getTag());
							enemies.add(toAdd);
						}
						
						this.spawnTimes--;
					}
				}
				
			}
		}
	}

	public double getX() {return this.x;}
	public double getY() {return this.y;}
	public double getSpawnDistance() {return this.spawnDistance;}
}
