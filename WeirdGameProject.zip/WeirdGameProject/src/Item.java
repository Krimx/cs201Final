import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Item {
	private String type;
	private double x,y;
	private int healAmount, maxHealthBoost, maxManaBoost;
	private double damageBoost;
	private BufferedImage image;
	private boolean usable, spellItem;
	private String lore;
	
	public Item(double x, double y, String type) {
		this.x = x;
		this.y = y;
		this.type = type;
		this.healAmount = 0;
		this.maxHealthBoost = 0;
		this.usable = false;
		this.lore = "";
		this.damageBoost = 1;
		this.maxManaBoost = 0;
		this.spellItem = false;
		
		if (this.type.equals("healthUp")) {
			this.maxHealthBoost = 25;
			this.usable = true;
			this.lore = "T1 Health Boost [] +25 Max Health []";
		}
		else if (this.type.equals("healthUp2")) {
			this.maxHealthBoost = 50;
			this.usable = true;
			this.lore = "T2 Health Boost [] +50 Max Health []";
		}
		else if (this.type.equals("healthUp3")) {
			this.maxHealthBoost = 75;
			this.usable = true;
			this.lore = "T3 Health Boost [] +75 Max Health []";
		}
		else if (this.type.equals("healthUp4")) {
			this.maxHealthBoost = 100;
			this.usable = true;
			this.lore = "T4 Health Boost [] +100 Max Health []";
		}
		else if (this.type.equals("faceSigil")) {
			this.lore = "Face Sigil";
		}
		else if (this.type.equals("damageUp1")) {
			this.damageBoost = 1.5;
			this.usable = true;
			this.lore = "T1 Damage Boost [] *1.5 Damage []";
		}
		else if (this.type.equals("damageUp2")) {
			this.damageBoost = 2;
			this.usable = true;
			this.lore = "T2 Damage Boost [] *2 Damage []";
		}
		else if (this.type.equals("damageUp3")) {
			this.damageBoost = 3;
			this.usable = true;
			this.lore = "T3 Damage Boost [] *3 Damage []";
		}
		else if (this.type.equals("manaUp1")) {
			this.maxManaBoost = 50;
			this.usable = true;
			this.lore = "T1 Mana Boost [] +50 Max Mana []";
		}
		else if (this.type.equals("manaUp2")) {
			this.maxManaBoost = 100;
			this.usable = true;
			this.lore = "T2 Mana Boost [] +100 Max Mana []";
		}
		else if (this.type.equals("manaUp3")) {
			this.maxManaBoost = 200;
			this.usable = true;
			this.lore = "T3 Mana Boost [] +200 Max Mana []";
		}
		else if (this.type.equals("blackHeart")) {
			this.lore = "Black Heart";
		}
		else if (this.type.equals("rumbleTome")) {
			this.usable = true;
			this.lore = "Spell Tome [] Rumble Spell";
		}
		else if (this.type.equals("essence")) {
			this.usable = false;
			this.lore = "Spell Essence [] Used to make spells";
		}
		else if (this.type.equals("ooze")) {
			this.usable = false;
			this.lore = "Ooze";
		}
		else if (this.type.equals("daggerTome")) {
			this.usable = true;
			this.lore = "Spell Tome [] Dagger Spell";
		}
		else if (this.type.equals("truffle")) {
			this.usable = false;
			this.lore = "Truffle";
		}
		else if (this.type.equals("pinGem")) {
			this.usable = false;
			this.lore = "Pin Gem";
		}
		else {
			this.lore = "Womp Womp";
		}
	}
	
	public void setImage(Resources recs) {
		if (this.type.equals("heal")) this.image = recs.healthItem;
		if (this.type.equals("faceSigil")) this.image = recs.faceSigil;
		if (this.type.equals("blackHeart")) this.image = recs.blackHeart;
		if (this.type.equals("healthUp")) this.image = recs.healthUp;
		if (this.type.equals("healthUp2")) this.image = recs.healthUp2;
		if (this.type.equals("healthUp3")) this.image = recs.healthUp3;
		if (this.type.equals("healthUp4")) this.image = recs.healthUp4;
		if (this.type.equals("damageUp1")) this.image = recs.damageUp1;
		if (this.type.equals("damageUp2")) this.image = recs.damageUp2;
		if (this.type.equals("damageUp3")) this.image = recs.damageUp3;
		if (this.type.equals("manaUp1")) this.image = recs.manaUp1;
		if (this.type.equals("manaUp2")) this.image = recs.manaUp2;
		if (this.type.equals("manaUp3")) this.image = recs.manaUp3;
		if (this.type.equals("rumbleTome")) this.image = recs.rumbleTome;
		if (this.type.equals("essence")) this.image = recs.essence;
		if (this.type.equals("ooze")) this.image = recs.ooze;
		if (this.type.equals("daggerTome")) this.image = recs.daggerTome;
	}
	
	/********************************************************************************
	* render()                                                                      *
	* renders to jpanel                                                             *
	*                                                                               *
	* Parameters:                                                                   *
	* Graphics g                                                                    *
	* int scrWidth                                                                  *
	* int scrHeight                                                                 *
	* int mult                                                                      *
	* Camera camera                                                                 *
	* Resources recs                                                                *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void render(Graphics g, int scrWidth, int scrHeight, int mult, Camera camera, Resources recs) {
		double scale = (double) (((double) (scrWidth) / (double) (mult)) * 10);
		
		int xOffset = scrWidth / 2;
		int yOffset = scrHeight / 2;
		
		int renderW = (int) (2 * scale);
		int renderH = (int) (2 * scale);
		
		int renderX = (int) ((x * scale) + xOffset - camera.getX() - ((double) renderW / 2.0));
		int renderY = (int) ((y * scale) + yOffset - camera.getY() - ((double) renderH / 2.0));
		
		BufferedImage toRender = null;

		setImage(recs);
		
		//g.setColor(Color.blue);
		//g.fillRect(renderX, renderY, renderW, renderH);
		
		g.drawImage(this.image, renderX, renderY, renderW, renderH, null);
		

		//g.drawImage(recs.playerShadow, renderX, (int) (renderY + (renderH * (15.0 / 18.0))), (int) renderW, (int) (renderH * (6.0 / 18.0)), null);
		
		//g.drawImage(sprite, renderX, renderY, (int) renderW, (int) renderH, null);
		//g.fillRect(renderX, renderY, (int) renderW, (int) renderH);
	}
	
	public void setHealAmount(int amount) {this.healAmount = amount;}
	public void setImage(BufferedImage image) {this.image = image;}
	public void setX(double x) {this.x = x;}
	public void setY(double y) {this.y = y;}
	public void setMaxHealthBoost(int amount) {this.maxHealthBoost = amount;}
	public void setDamageBoost(double amount) {this.damageBoost = amount;}

	public double getX() {return this.x;}
	public double getY() {return this.y;}
	public String getType() {return this.type;}
	public int getHealAmount() {return this.healAmount;}
	public BufferedImage getImage() {return this.image;}
	public int getMaxHealthBoost() {return this.maxHealthBoost;}
	public int getManaBoost() {return this.maxManaBoost;}
	public boolean getUsable() {return this.usable;}
	public String getLore() {return this.lore;}
	public double getDamageBoost() {return this.damageBoost;}
	
	/********************************************************************************
	* clone()                                                                       *
	* creates a clone of item and sends it out                                      *
	*                                                                               *
	* Parameters: none                                                              *
	*                                                                               *
	* Return Type: Item toOut                                                       *
	*                                                                               *
	* Test Cases: none                                                              *
	********************************************************************************/
	public Item clone() {
		Item toOut = new Item(this.x, this.y, this.type);
		toOut.setHealAmount(healAmount);
		toOut.setMaxHealthBoost(this.maxHealthBoost);
		toOut.setImage(this.image);
		toOut.setDamageBoost(this.damageBoost);
		
		return toOut;
	}
	
	public String toString() {
		String toOut = "";
		
		toOut += this.type + " ";
		toOut += this.x + " ";
		toOut += this.y;
		
		return toOut;
	}
}
