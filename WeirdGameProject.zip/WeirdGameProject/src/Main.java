import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.swing.*;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;


/*TODO:
 * Spellbook to show what spell is selected
 * Item to modify damage output
 * Different types of enemies
 * 	Tank, Fast, Damage, Projectile
 * More chest types
 * Possibly different colored walls and tiles based on difficulty area
 * Speed modifier item or sumt
 * Spell cooldown item
 * Finish making the map
*/


class Screen extends JPanel {
	private static final long serialVersionUID = 1L;
	public Camera camera = new Camera(0,0);
	public int scale = 800;
	public Resources recs = new Resources();
	public Color bgPurple = new Color(9,0,26);
	public Font playerUIFont, extractFont, titleFont, pausedFont;
	public ArrayList<int[]> stars = new ArrayList<int[]>();
	public int yPackStart = 100;
	public int menuScroll = 0;
	
	public int maxFPS = 60;
	public long lastTimeMillis = 0, thisTimeMillis = 0;
	public float timeBetweenFrames;
	
	public int overR = 0, overG = 0, overB = 0, overA = 0;
	
	public Screen() {
		try {
		     playerUIFont = Font.createFont(Font.TRUETYPE_FONT, new File("Recs/Fonts/FFFFORWA.TTF")).deriveFont(12f);
		     extractFont = Font.createFont(Font.TRUETYPE_FONT, new File("Recs/Fonts/FFFFORWA.TTF")).deriveFont(48f);
		     titleFont = Font.createFont(Font.TRUETYPE_FONT, new File("Recs/Fonts/FFFFORWA.TTF")).deriveFont(102f);
		     pausedFont = Font.createFont(Font.TRUETYPE_FONT, new File("Recs/Fonts/FFFFORWA.TTF")).deriveFont(15f);
		     GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		     ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("Recs/Fonts/FFFFORWA.TTF")));
		} catch (Exception e) {e.printStackTrace();}
		this.timeBetweenFrames = 1000.0f / (float) maxFPS;
	}
	
	/********************************************************************************
	* paintComponent()                                                              *
	* used for drawing to JFrame                                                    *
	*                                                                               *
	* Parameters:                                                                   *
	* Graphics g                                                                    *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void paintComponent(Graphics g) {
		try {
			Thread.sleep((long) timeBetweenFrames);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		paintPane(g);
		repaint();
	}
	
	/********************************************************************************
	* paintPane()                                                                   *
	* stuff happens here; just condenses painting functions                         *
	*                                                                               *
	* Parameters:                                                                   *
	* Graphics g                                                                    *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void paintPane(Graphics g) {
		scale = Main.scrWidth;
		if (Main.gamestate == 'g') {
			mainGame(g);
		}
		else if (Main.gamestate == 'm') {
			mainMenu(g);
		}
		else if (Main.gamestate == 'p') {
			pauseMenu(g);
		}
		else if (Main.gamestate == 'e') {
			extractCutscene(g);
		}
	}
	public void setBackground(Graphics g, Color color) {
		Color toReturn = g.getColor();
		g.setColor(color);
		g.fillRect(0, 0, Main.scrWidth, Main.scrHeight);
		g.setColor(toReturn);
	}
	public void mainMenu(Graphics g) {
		try {
			setBackground(g, new Color(15,0,22));
			Main.quitButton.render(g);
			Main.playButton.render(g);
			Main.cgButton.render(g);
			
			
			
			if (!Main.craftingGuideOpen) {
				Main.craftButton.render(g);
				
				drawMainMenuUI(g);
				g.setFont(playerUIFont);
				g.setColor(Color.white);
				g.drawString("Essence: " + Main.player.getSpellEssence(), 450 + ((80 - 52) / 2),40);
			}
			else {
				craftingGuide(g);
			}
			
		}
		catch(Exception e) {};
	}
	public void pauseMenu(Graphics g) {
		setBackground(g, bgPurple);
		g.setFont(titleFont);
		g.setColor(Color.white);
		g.drawString("Paused", Main.scrWidth / 2 - 250, 150);
		
		if (Main.askToLeave) {
			g.setColor(new Color(87,66,98));
			g.fillRect(Main.scrWidth / 2 - 300, Main.scrHeight / 2 - 100, 600, 200);
			
			g.setColor(Color.white);
			g.setFont(playerUIFont);
			g.drawString("Warning, exiting now means you will lose your current session progress.", Main.scrWidth / 2 - 290, Main.scrHeight / 2 - 80);
			
			Main.stayButton.render(g);
			Main.leaveButton.render(g);
		}
		else {
			Main.exitButton.render(g);
		}
	}
	public void mainGame(Graphics g) {
		try {
			setBackground(g, bgPurple);
			
			for (int i = 0; i < Main.blocks.size(); i++) {
				Main.blocks.get(i).render(g, Main.scrWidth, Main.scrHeight, scale, camera, recs);
				//Main.blocks.get(i).getHitbox().render(g, Main.scrWidth, Main.scrHeight, scale, camera);
			}
			
			for (int i = 0; i < Main.tiles.size(); i++) {
				Main.tiles.get(i).render(g, Main.scrWidth, Main.scrHeight, scale, camera, recs);
				//Main.blocks.get(i).getHitbox().render(g, Main.scrWidth, Main.scrHeight, scale, camera);
			}
			
			for (int i = 0; i < Main.inters.size(); i++) {
				Main.inters.get(i).render(g, Main.scrWidth, Main.scrHeight, scale, camera, recs);
				//Main.blocks.get(i).getHitbox().render(g, Main.scrWidth, Main.scrHeight, scale, camera);
			}
			
			for (int i = 0; i < Main.items.size(); i++) {
				Main.items.get(i).render(g, Main.scrWidth, Main.scrHeight, scale, camera, recs);
				//Main.blocks.get(i).getHitbox().render(g, Main.scrWidth, Main.scrHeight, scale, camera);
			}

			Main.player.render(g, Main.scrWidth, Main.scrHeight, scale, camera, recs);
			
			for (int  i = 0; i < Main.enemies.size(); i++) {
				Main.enemies.get(i).render(g, Main.scrWidth, Main.scrHeight, scale, camera, recs);
			}
			
			for (int i = 0; i < Main.spells.size(); i++) {
				Main.spells.get(i).render(g, Main.scrWidth, Main.scrHeight, scale, camera, recs);
			}
			
			for (int i = 0; i < Main.particles.size(); i++) {
				Main.particles.get(i).Render(g, Main.scrWidth, Main.scrHeight, scale, camera, recs, this);
			}
			
			/*
			for (int i = 0; i < Main.diffs.size(); i++) {
				Main.diffs.get(i).render(g, Main.scrWidth, Main.scrHeight, scale, camera, recs);
			}
			*/
			Color overlay = new Color(0,0,0,0);
			if (Main.currentDiff > -1) {
				if (overR < Main.diffs.get(Main.currentDiff).getColor().getRed()) overR++;
				if (overR > Main.diffs.get(Main.currentDiff).getColor().getRed()) overR--;
				if (overG < Main.diffs.get(Main.currentDiff).getColor().getGreen()) overG++;
				if (overG > Main.diffs.get(Main.currentDiff).getColor().getGreen()) overG--;
				if (overB < Main.diffs.get(Main.currentDiff).getColor().getBlue()) overB++;
				if (overB > Main.diffs.get(Main.currentDiff).getColor().getBlue()) overB--;
				if (overA < Main.diffs.get(Main.currentDiff).getColor().getAlpha()) overA++;
				if (overA > Main.diffs.get(Main.currentDiff).getColor().getAlpha()) overA--;
			}
			else {
				if (overR > 0) overR--;
				if (overG > 0) overG--;
				if (overB > 0) overB--;
				if (overA > 0) overA--;
			}
			overlay = new Color(overR, overG, overB, overA);
			g.setColor(overlay);
			g.fillRect(0, 0, Main.scrWidth, Main.scrHeight);
			
			
			Main.player.renderUI(g, playerUIFont, Main.scrWidth, Main.scrHeight, recs);
			
			minimap(g);

			//Main.player.getLeftBox().render(g, Main.scrWidth, Main.scrHeight, scale, camera);
			//Main.player.getRightBox().render(g, Main.scrWidth, Main.scrHeight, scale, camera);
			//Main.player.getUpBox().render(g, Main.scrWidth, Main.scrHeight, scale, camera);
			//Main.player.getDownBox().render(g, Main.scrWidth, Main.scrHeight, scale, camera);
			
			if (Main.displayPack) {
				g.setColor(new Color(50,50,50,100));
				g.fillRect(200, yPackStart - 10, (Main.player.getMaxPackSize() * 80) + ((Main.player.getMaxPackSize() - 1) * 10), 100);
				
				for (int i = 0; i < Main.player.getPack().size(); i++) {
					int offset = (i + 1) * 10;
					int renderSpot = i * 80;
					g.drawImage(Main.player.getPack().get(i).getImage(), renderSpot + offset + 200, yPackStart, 80, 80, null);
					
					if (Main.packSlotsReady) {
						if (Main.packSlots.get(i).hasPoint(Main.mouse.getX(), Main.mouse.getY())) {
							int toStartX = renderSpot + offset + 200;
							int toStartY = yPackStart + 80 + 20;
							int iconScale = 2;
							g.drawImage(recs.rightClickIcon, toStartX, toStartY, 7 * iconScale, 9 * iconScale, null);
							g.setFont(playerUIFont);
							g.setColor(Color.white);
							g.drawString("Drop", toStartX + (7 * iconScale) + 5, toStartY + (9 * iconScale));
							
							ArrayList<String> flavorText = new ArrayList<String>();
							Scanner lore = new Scanner((Main.player.getPack().get(i).getLore()));
							String toAdd = "";
							boolean added = false;
							while (lore.hasNext()) {
								String bit = lore.next();
								if (bit.equals("[]")) {
									flavorText.add(toAdd);
									added = true;
									toAdd = "";
								}
								else {
									toAdd += bit + " ";
									added = false;
								}
							}
							if (!added) flavorText.add(toAdd);
							
							for (int j = 0; j < flavorText.size(); j++) {
								int toY = yPackStart - 50 + (j * 25);
								g.drawString(flavorText.get(j), toStartX, toY);
							}
							
							
							if (Main.player.getPack().get(i).getUsable()) {
								g.drawImage(recs.leftClickIcon, toStartX, toStartY + 25, 7 * iconScale, 9 * iconScale, null);
								g.setFont(playerUIFont);
								g.setColor(Color.white);
								g.drawString("Use", toStartX + (7 * iconScale) + 5, toStartY + (9 * iconScale) + 25);
							}
						}
					}
				}
			}
			
			if (Main.extracting) {
				g.setColor(Color.white);
				g.setFont(extractFont);
				int countdown = Main.extractionCountdown / Main.tps;
				
				int mod = 30 - Main.extractionCountdown % Main.tps;
				
				g.drawString(String.valueOf(countdown), Main.scrWidth / 2, Main.scrHeight - 60 + (((mod / 2) * (mod * 2)) / 2));
				
				if (Main.extractionCountdown < 0) {
					int alpha = (int) ((double) Math.abs(Main.extractionCountdown) * 15);
					if (alpha > 255) alpha = 255;
					
					g.setColor(new Color(0,0,0,alpha));
					g.fillRect(0, 0, Main.scrWidth, Main.scrHeight);
				}
			}
		}
		catch(Exception e) {}
		
		
	}
	public void extractCutscene(Graphics g) {
		setBackground(g, new Color(6,0,17));
		
		if (stars.size() == 0) prepExtractStars();
		
		for (int i = 0; i < stars.size(); i++) {
			stars.get(i)[0]--;
			if (stars.get(i)[0] < -3) {
				stars.get(i)[0] = Main.scrWidth + 3;
			}
			
			g.setColor(Color.white);
			g.fillOval(stars.get(i)[0], stars.get(i)[1], 2, 2);
		}
		
		
		if (Main.extractCutsceneTime > ((Main.tps * 5) - 30)) {
			int alpha = 255 - (int) (Math.abs(Main.extractCutsceneTime - (Main.tps * 5)) * 8.5);
			g.setColor(new Color(0,0,0,alpha));
			g.fillRect(0, 0, Main.scrWidth, Main.scrHeight);
		}
		
		
		double input = (double) ((Main.tps * 5) - Main.extractCutsceneTime) / 150.0;
		int xPos = (int) (Math.pow(input - 1,  3) * Main.scrWidth);
		
		int rMod = 15;
		int rotMult = 10;
		
		Graphics2D g2d = (Graphics2D) (g);
		g2d.rotate(input * rotMult, xPos + (Main.scrWidth / 2) + (4 * rMod / 2), (Main.scrHeight / 2));
		g2d.drawImage(recs.charSprite1, xPos + (Main.scrWidth / 2), (Main.scrHeight / 2) - (6 * rMod / 2), (4 * rMod), (6 * rMod), null);
		g2d.rotate(-input * rotMult, xPos + (Main.scrWidth / 2) + (4 * rMod / 2), (Main.scrHeight / 2));
	}
	public void prepExtractStars() {
		for (int i = 0; i < 100; i++) {
			int[] toAdd = {ThreadLocalRandom.current().nextInt(0, Main.scrWidth), ThreadLocalRandom.current().nextInt(0, Main.scrHeight)};
			stars.add(toAdd);
		}
	}
	public void minimap(Graphics g) {
		int xOff = (int) ((double) Main.scrWidth * (1.0/10.0));
		int yOff = (int) ((double) Main.scrHeight * (7.0/8.0));
		double scaleUp = 1;
		int toX = 0;
		int toY = 0;
		for (int i = 0; i < Main.blocks.size(); i++) {
			scaleUp = Main.blocks.get(i).getScale();
			
			double dis = Main.player.distance(Main.player.getX(), Main.player.getY(), Main.blocks.get(i).getX() * scaleUp, Main.blocks.get(i).getY() * scaleUp);
			
			if (dis <= 150) {
				
				toX = (int) ((Main.blocks.get(i).getX() * scaleUp - Main.player.getX()));
				toY = (int) ((Main.blocks.get(i).getY() * scaleUp - Main.player.getY()));
				g.setColor(new Color(255,255,255,100));
				g.fillRect(toX + xOff, toY + yOff, (int) scaleUp, (int) scaleUp);
			}
		}
		g.setColor(new Color(255,0,0,100));
		g.fillRect(xOff, yOff, (int) scaleUp, (int) scaleUp);
	}
	public void drawMainMenuUI(Graphics g) {
		int xOffset = 200;
		int yOffset = 100;
		int rw = 80;
		int margin = 5;
		
		g.drawImage(recs.packIcon, xOffset + 20, yOffset - 80, 40, 45, null);
		g.setFont(playerUIFont);
		g.setColor(Color.white);
		g.drawString("Pack", xOffset + 20, yOffset - 15);
		for (int i = 0; i < Main.menuPackSlots.size(); i++) {
			Main.menuPackSlots.get(i).setX(xOffset - margin);
			Main.menuPackSlots.get(i).setY(yOffset + (i * (rw + (margin * 2))) - margin);
			Main.menuPackSlots.get(i).setW(rw + (margin * 2));
			g.setFont(playerUIFont);
			Main.menuPackSlots.get(i).render(g, margin, recs, menuScroll);
		}

		xOffset = 700;
		yOffset = 100;
		g.drawImage(recs.invIcon, xOffset + 20, yOffset - 80, 40, 45, null);
		g.setFont(playerUIFont);
		g.setColor(Color.white);
		g.drawString("Inventory", xOffset + 5, yOffset - 15);
		for (int i = 0; i < Main.menuInvSlots.size(); i++) {
			Main.menuInvSlots.get(i).setX(xOffset - margin);
			Main.menuInvSlots.get(i).setY(yOffset + (i * (rw + (margin * 2))) - margin);
			Main.menuInvSlots.get(i).setW(rw + (margin * 2));
			g.setFont(playerUIFont);
			Main.menuInvSlots.get(i).render(g, margin, recs, menuScroll);
		}
		
		xOffset = 450;
		yOffset = 100;
		for (int i = 0; i < Main.menuCraftingSlots.size(); i++) {
			Main.menuCraftingSlots.get(i).setX(xOffset - margin);
			Main.menuCraftingSlots.get(i).setY(yOffset + (i * (rw + (margin * 2))) - margin);
			Main.menuCraftingSlots.get(i).setW(rw + (margin * 2));
			g.setFont(playerUIFont);
			Main.menuCraftingSlots.get(i).render(g, margin, recs, menuScroll);
		}
	}
	public void craftingGuide(Graphics g) {
		int xOffset = 200;
		int yOffset = 100;
		int rw = 80;
		int margin = 5;
		
		for (int i = 0; i < Main.recipes.size(); i++) {
			int toY = (yOffset * (i + 1)) + (margin * (i + 1));
			
			BufferedImage toOutRender = Main.recipes.get(i).getOutSprite();
			g.drawImage(toOutRender, xOffset, toY - menuScroll, rw, rw, null);
			
			g.drawImage(recs.leftArrow, xOffset + rw + margin, toY - menuScroll, rw, rw, null);
			
			int xIns = 0;
			for (int j = 0; j < Main.recipes.get(i).getInSprites().size(); j++) {
				int toX = xOffset + (rw * 2) + (margin * 2) + (margin * j) + (rw * j);
				g.drawImage(Main.recipes.get(i).getInSprites().get(j), toX, toY - menuScroll, rw, rw, null);
				xIns = toX;
			}
			
			if (Main.recipes.get(i).getReqEssence() > 0) {
				g.setFont(playerUIFont);
				g.setColor(Color.white);
				g.drawString("+" + Main.recipes.get(i).getReqEssence() + " Essence", xIns + (rw) + (margin * 2), toY - menuScroll + (rw / 2));
			}
		}
	}
}

public class Main {
	public static JFrame frame = new JFrame();
	public static Container cont = frame.getContentPane();
	public static Screen scr = new Screen();
	public static Keyboard keys = new Keyboard();
	public static Mouse mouse = new Mouse(true);
	
	public static boolean running = true;
	public static int tps = 60, scrWidth, scrHeight;
	public static char gamestate = 'm';
	public static boolean displayPack = false, packSlotsReady = false, canDisplayPack = true;
	public static boolean menuLoaded = false, askToLeave = false, craftingGuideOpen = false;;
	public static int extractionCountdown = tps * 6, extractCutsceneTime = Main.tps * 5;
	public static boolean extracting = false;
	public static int currentDiff = 1;
	
	public static Player player = new Player();
	public static Resources recs = new Resources();

	public static Button quitButton = new Button(10,10,130,35,"Exit to Desktop");
	public static Button cgButton = new Button(10,55,125,35,"Crafting Guide");
	public static Button craftButton = new Button(450 + ((80 - 52) / 2),50,54,35,"Craft");
	public static Button playButton = new Button(10,100,50,35,"Play");
	public static Button exitButton = new Button(scrWidth / 2 - 67, 400 - 12, 134, 40,"Exit to Menu");
	public static Button stayButton = new Button(scrWidth / 2 - 40, scrHeight / 2 - 20, 80, 40,"Cancel");
	public static Button leaveButton = new Button(scrWidth / 2 - 24, scrHeight / 2 + 20, 48, 40,"Exit");
	
	public static ArrayList<Block> blocks = new ArrayList<Block>();
	public static ArrayList<Tile> tiles = new ArrayList<Tile>();
	public static ArrayList<Spell> spells = new ArrayList<Spell>();
	public static ArrayList<Interactable> inters = new ArrayList<Interactable>();
	public static ArrayList<Item> items = new ArrayList<Item>();
	public static ArrayList<BackpackSlot> packSlots = new ArrayList<BackpackSlot>();
	public static ArrayList<EnemySpawner> spawnLocs = new ArrayList<EnemySpawner>();
	public static ArrayList<DiffArea> diffs = new ArrayList<DiffArea>();

	public static ArrayList<MenuSlot> menuPackSlots = new ArrayList<MenuSlot>();
	public static ArrayList<MenuSlot> menuInvSlots = new ArrayList<MenuSlot>();
	public static ArrayList<MenuSlot> menuCraftingSlots = new ArrayList<MenuSlot>();
	public static ArrayList<Item> craftingItems = new ArrayList<Item>();
	public static ArrayList<CraftingRecipe> recipes = new ArrayList<CraftingRecipe>();
	public static ArrayList<Enemy> enemies = new ArrayList<Enemy>();
	public static ArrayList<Particle> particles = new ArrayList<Particle>();
	
	//Credit to Kelsun on StackOverflow
	public static <T> boolean listEqualsIgnoreOrder(List<T> list1, List<T> list2) {
	    return new HashSet<>(list1).equals(new HashSet<>(list2));
	}
	
	/********************************************************************************
	* init()                                                                        *
	* initializes the program, mainly JFrame                                        *
	*                                                                               *
	* Parameters: none                                                              *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public static void init() {
		cont.add(scr);
		//frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setSize(800,800);
		frame.setResizable(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Another Average Indie Game");
		frame.addKeyListener(keys);
		frame.addMouseListener(mouse);
		frame.addMouseMotionListener(mouse);
		frame.addMouseWheelListener(mouse);
		frame.setFocusTraversalKeysEnabled(false);
		frame.setUndecorated(true);
		
		frame.setVisible(true);
		
		loadMap("map1");
		
		player.initStats("save1", recs, true);
		
		for (Tile tile : tiles) {
			tile.doInteractables(inters);
		}
		
		for (Interactable inter : inters) {
			inter.rollChestItems();
		}

		quitButton.setLabelFont(scr.playerUIFont);
		craftButton.setLabelFont(scr.playerUIFont);
		playButton.setLabelFont(scr.playerUIFont);
		exitButton.setLabelFont(scr.pausedFont);
		stayButton.setLabelFont(scr.pausedFont);
		leaveButton.setLabelFont(scr.pausedFont);
		cgButton.setLabelFont(scr.playerUIFont);

		recipes.add(new CraftingRecipe("healthUp", recs));
		recipes.add(new CraftingRecipe("healthUp2", recs));
		recipes.add(new CraftingRecipe("healthUp3", recs));
		recipes.add(new CraftingRecipe("healthUp4", recs));
		recipes.add(new CraftingRecipe("damageUp1", recs));
		recipes.add(new CraftingRecipe("damageUp2", recs));
		recipes.add(new CraftingRecipe("damageUp3", recs));
		recipes.add(new CraftingRecipe("manaUp1", recs));
		recipes.add(new CraftingRecipe("manaUp2", recs));
		recipes.add(new CraftingRecipe("manaUp3", recs));
		recipes.add(new CraftingRecipe("rumbleTome", recs));
		recipes.add(new CraftingRecipe("daggerTome", recs));
	}
	
	/********************************************************************************
	* run()                                                                         *
	* runs the program at a given amount of ticks per second                        *
	*                                                                               *
	* Parameters: none                                                              *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public static void run() {
		long lastTime = System.nanoTime(); //Init time var
	    final double ns = 1000000000.0 / tps; //Control ticks per second
	    double delta = 0;
	    while(running){ //Game loop boolean
	        long now = System.nanoTime(); //Far for now time
	        delta += (now - lastTime) / ns; //While in running loop, wait until two time vars are equal
	        lastTime = now; //Reset
	        while(delta >= 1) { //Wait until time is less than one
	        	updateSystem();
	        	mainLoop();
	            delta--; //Remove
	            }
	        } 

	    System.exit(0); //Once done with game loop, shut everything down
	}

	public static void main(String[] args) {
		init();
		run();
	}
	
	/********************************************************************************
	* updateSystem()                                                                *
	* updates fields determined by system processes that are needed for other functions*
	*                                                                               *
	* Parameters: none                                                              *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public static void updateSystem() {
		scrWidth = cont.getWidth();
		scrHeight = cont.getHeight();
	}

	/********************************************************************************
	* mainLoop()                                                                    *
	* method called in run() every tick; everything happens in here                 *
	*                                                                               *
	* Parameters: none                                                              *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public static void mainLoop() {
		if (gamestate == 'g') {
			mainGame();
		}
		else if (gamestate == 'm') {
			particles.clear();
			mainMenu();
		}
		else if (gamestate == 'p') {
			particles.clear();
			pauseMenu();
		}
		else if (gamestate == 'e') {
			particles.clear();
			extractCutscene();
		}
	}
	public static void mainMenu() {
		loadMenu();
		scr.menuScroll -= mouse.getScrollDifference();
		if (scr.menuScroll < 0) scr.menuScroll = 0;
		
		if (quitButton.hasMouse(mouse)) {
			if (mouse.LEFTCLICKED()) {
				unloadCraft();
				saveData("save1");
				running = false;
			}
		}
		
		if (cgButton.hasMouse(mouse)) {
			if (mouse.LEFTCLICKED()) {
				if (!craftingGuideOpen) craftingGuideOpen = true;
				else craftingGuideOpen = false;
			}
		}
		
		for (int i = 0; i < menuPackSlots.size(); i++) {
			if (menuPackSlots.get(i).hasPoint(mouse.getX(), mouse.getY() + scr.menuScroll)) {
				if (mouse.LEFTCLICKED()) {
					switchPackInv(i, true);
				}
				if (mouse.RIGHTCLICKED()) {
					putInCraft(i, true, false);
				}
			}
		}

		for (int i = 0; i < menuInvSlots.size(); i++) {
			if (menuInvSlots.get(i).hasPoint(mouse.getX(), mouse.getY() + scr.menuScroll)) {
				if (mouse.LEFTCLICKED()) {
					if (Main.player.getPack().size() < Main.player.getMaxPackSize()) {
						switchPackInv(i, false);
					}
					
				}
				if (mouse.RIGHTCLICKED()) {
					putInCraft(i, false, false);
				}
			}
		}

		for (int i = 0; i < menuCraftingSlots.size(); i++) {
			if (menuCraftingSlots.get(i).hasPoint(mouse.getX(), mouse.getY() + scr.menuScroll)) {
				if (mouse.LEFTCLICKED()) {
					if (Main.player.getPack().size() < Main.player.getMaxPackSize()) {
						putInCraft(i, true, true);
					}
					
				}
				if (mouse.RIGHTCLICKED()) {
					putInCraft(i, false, true);
				}
			}
		}
		
		if (craftButton.hasMouse(mouse)) {
			if (mouse.LEFTCLICKED()) {
				craft();
			}
		}
		
		if (playButton.hasMouse(mouse)) {
			if (mouse.LEFTCLICKED()) {
				unloadCraft();
				loadGame();
				gamestate = 'g';
			}
		}
	}
	
	/********************************************************************************
	* loadGame()                                                                    *
	* loads the main gameplay (map, stats, etc)                                     *
	*                                                                               *
	* Parameters: none                                                              *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public static void loadGame() {
		saveData("save1");
		player.setDead(false);
		extractionCountdown = tps * 6;
		extractCutsceneTime = Main.tps * 5;
		extracting = false;

		scr.camera.setX(0);
		scr.camera.setY(0);
		
		enemies.clear();
		
		player.setPos(0,0);
		player.setMaxHealth(100);
		player.setHealth(player.getMaxHealth());
		player.setUsedT1Health(false);
		player.setDamageMult(1.0);
		player.setSpeedMult(1.0);
		
		player.initStats("save1", recs, false);

		/*
		enemies.add(new Enemy("spurt", 3, 10, -5, 5));
		enemies.add(new Enemy("spurt", 3, 10, -6, 5));
		enemies.add(new Enemy("spurt", 3, 10, -7, 5));
		enemies.add(new Enemy("spurt", 3, 10, -8, 5));
		enemies.add(new Enemy("spurt", 3, 10, -9, 5));
		*/
	}
	public static void switchPackInv(int i, boolean pack) {
		if (pack) {
			player.getInv().add(player.getPack().get(i));
			player.getPack().remove(i);
			menuLoaded = false;
		}
		else {
			player.getPack().add(player.getInv().get(i));
			player.getInv().remove(i);
			menuLoaded = false;
		}
		
		loadMenu();
	}
	public static void putInCraft(int i, boolean pack, boolean remove) {
		menuPackSlots.clear();
		menuInvSlots.clear();
		menuCraftingSlots.clear();
		
		if (!remove) {
			if (pack) {
				craftingItems.add(player.getPack().get(i));
				player.getPack().remove(i);
				menuLoaded = false;
			}
			else {
				craftingItems.add(player.getInv().get(i));
				player.getInv().remove(i);
				menuLoaded = false;
			}
		}
		else {
			if (pack) {
				player.getPack().add(craftingItems.get(i));
				craftingItems.remove(i);
				menuLoaded = false;
			}
			else {
				player.getInv().add(craftingItems.get(i));
				craftingItems.remove(i);
				menuLoaded = false;
			}
		}
		
		loadMenu();
	}
	public static void unloadCraft() {
		for (Item item : craftingItems) {
			player.getInv().add(item.clone());
		}
	}
	public static void craft() {
		ArrayList<String> types = new ArrayList<String>();
		for (Item item : craftingItems) {
			types.add(item.getType());
		}

		for (CraftingRecipe recipe : recipes) {
			if (listEqualsIgnoreOrder(types, recipe.getInputs()) && types.size() == recipe.getInputs().size() && Main.player.getSpellEssence() >= recipe.getReqEssence()) {
				player.addEssence(-recipe.getReqEssence());
				Item toOut = new Item(0, 0, recipe.getOutput());
				toOut.setImage(recs);
				craftingItems.clear();
				craftingItems.add(toOut);
				menuLoaded = false;
				loadMenu();
				break;
			}
		}
	}
	public static void pauseMenu() {
		if (keys.ESCAPETYPED()) gamestate = 'g';

		exitButton.setPos(scrWidth / 2 - 67, scrHeight / 2 - 32);
		stayButton.setPos(scrWidth / 2 - 40, scrHeight / 2 - 24);
		leaveButton.setPos(scrWidth / 2 - 24, scrHeight / 2 + 24);
		
		if (askToLeave) {
			if (stayButton.hasMouse(mouse)) {
				if (mouse.LEFTCLICKED()) {
					askToLeave = false;
				}
			}
			if (leaveButton.hasMouse(mouse)) {
				if (mouse.LEFTCLICKED()) {
					askToLeave = false;
					player.die();
					menuLoaded = false;
					gamestate = 'm';
				}
			}
		}
		else {
			if (exitButton.hasMouse(mouse)) {
				if (mouse.LEFTCLICKED()) {
					askToLeave = true;
				}
			}
		}
	}
	public static void extractCutscene() {
		if (extractCutsceneTime > 0) extractCutsceneTime--;
		else {
			extractCutsceneTime = tps * 5;
			gamestate = 'm';
		}
	}
	public static void mainGame() {
		menuLoaded = false;
		if (keys.ESCAPETYPED()) gamestate = 'p';
		if (keys.H()) scr.camera.shake(120, 5);
		else scr.camera.resetShake();
		
		canDisplayPack = false;
		player.pickupItems(items, recs);
		canDisplayPack = true;
		
		for (EnemySpawner spawner : spawnLocs) {
			
			double dis = player.distance(player.getX(), player.getY(), spawner.getX(), spawner.getY());
			if (dis <= spawner.getSpawnDistance()) {
				spawner.spawn(enemies);
			}
		}
		
		boolean hoveringOverPack = false;
		if (displayPack) {
			makePackSlots();
			for (int i = 0; i < player.getPack().size(); i++) {
				if (packSlots.get(i).hasPoint(mouse.getX(), mouse.getY())) hoveringOverPack = true;
			}
		}
		currentDiff = -1;
		for (int i = 0; i < diffs.size(); i++) {
			if (diffs.get(i).getHitbox().isColliding(player.getHitbox())) {
				currentDiff = i;
			}
		}
		
		
		player.doAbilities(keys, mouse, spells, hoveringOverPack, enemies);
		player.regenMana();
		player.updateCamera(scrWidth, scrHeight, scr.scale, scr.camera);
		player.animate();
		player.update(keys, mouse, blocks, inters, items, enemies);
		
		
		for (int i = 0; i < particles.size(); i++) {
			particles.get(i).update();
			if (particles.get(i).getLife() <= 0) {
				if (particles.get(i).getType().equals("explosion")) scr.remove(particles.get(i).getSprite());
				particles.remove(i);
			}
		}
		
		for (int i = 0; i < enemies.size(); i++) {
			enemies.get(i).update(player, blocks, inters, enemies, particles, spells, recs);
			
			if (enemies.get(i).getHealth() <= 0) {
				enemies.get(i).dropLoot(items);
				enemies.remove(i);
			}
		}
		
		int todo = player.interact(keys, inters, items, recs);
		
		if (todo == 1) {
			extracting = true;
		}
		
		if (extracting ) {
			if (extractionCountdown > -30) extractionCountdown--;
			else if (extractionCountdown == -30) {
				gamestate = 'e';
				extracting = false;
				extractionCountdown = tps * 6;
			}
		}
		
		for (int i = 0; i < spells.size(); i++) {
			spells.get(i).update(player, enemies, blocks, particles, scr, recs);
			
			if (spells.get(i).getHit()) spells.remove(i);
		}
		
		for (int i = 0; i < spells.size(); i++) {
			if (spells.get(i).getDuration() == 0) {
				spells.remove(i);
				i--;
			}
		}
		
		
		if (keys.TABTYPED()) {
			if (!displayPack) openInv();
			else closeInv();
		}
		
		if (displayPack) makePackSlots();
		
		if (displayPack) {
			if (mouse.RIGHTCLICKED()) {
				for (int i = 0; i < player.getPack().size(); i++) {
					if (packSlots.get(i).hasPoint(mouse.getX(), mouse.getY())) {
						Item toDrop = player.getPack().get(i).clone();
						int xMod = 0;
						int yMod = 0;

						if (player.getLastDir().equals("right")) xMod = 5;
						if (player.getLastDir().equals("left")) xMod = -5;
						if (player.getLastDir().equals("up")) yMod = -5;
						if (player.getLastDir().equals("down")) yMod = 5;
						
						toDrop.setX(player.getX() + xMod);
						toDrop.setY(player.getY() + yMod);
						items.add(toDrop);
						player.getPack().remove(i);
						break;
					}
				}
			}
			if (mouse.LEFTCLICKED()) {
				for (int i = 0; i < player.getPack().size(); i++) {
					if (packSlots.get(i).hasPoint(mouse.getX(), mouse.getY())) {
						if (player.useItem(i)) player.getPack().remove(i);
					}
				}
			}
		}
		
		if (player.getDead()) {
			menuLoaded = false;
			loadMenu();
			gamestate = 'm';
		}
	}
	public static void openInv() {
		displayPack = true;
		makePackSlots();
	}
	public static void closeInv() {
		displayPack = false;
		packSlots.clear();
		packSlotsReady = false;
	}
	public static int makePackSlots() {
		packSlots.clear();
		
		for (int i = 0; i < player.getPack().size(); i++) {
			int offset = (i + 1) * 10;
			int renderSpot = i * 80;
			packSlots.add(new BackpackSlot(200 + offset + renderSpot, scr.yPackStart,80,80));
			packSlotsReady = true;
		}
		return 1;
	}
	
	/********************************************************************************
	* loadMap()                                                                     *
	* loads the map from a .map file                                                *
	*                                                                               *
	* Parameters:                                                                   *
	* String mapName                                                                *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public static void loadMap(String mapName) {
		Scanner reader;
		boolean doingBlocks = false;
		boolean doingTiles = false;
		boolean doingInters = false;
		boolean doingDiffs = false;
		int crackOdds = 32;
		
		try {
			reader = new Scanner(new File("Maps/" + mapName + ".map"));
			
			while (reader.hasNextLine()) {
				String lineStr = reader.nextLine();
				
				if (lineStr.equals("Blocks {")) doingBlocks = true;
				
				if (doingBlocks) if (lineStr.equals("}")) doingBlocks = false;
				
				if (lineStr.equals("Tiles {")) doingTiles = true;
				
				if (doingTiles) if (lineStr.equals("}")) doingTiles = false;

				if (lineStr.equals("Interactables {")) doingInters = true;
				
				if (doingInters) if (lineStr.equals("}")) doingInters = false;

				if (lineStr.equals("Diffs {")) doingDiffs = true;
				
				if (doingDiffs) if (lineStr.equals("}")) doingDiffs = false;
				
				
				
				if (!lineStr.contains("}") && !lineStr.contains("{")) {
					if (doingBlocks) {
						Scanner line = new Scanner(lineStr);
						
						double x = Double.valueOf(line.next());
						double y = Double.valueOf(line.next());
						double scale = Double.valueOf(line.next());
						String type = line.next();
						int rot = Integer.valueOf(line.next());
						
						blocks.add(new Block(x,y,scale,type,rot));
					}
					
					if (doingTiles) {
						Scanner line = new Scanner(lineStr);
						
						double x = Double.valueOf(line.next());
						double y = Double.valueOf(line.next());
						double scale = Double.valueOf(line.next());
						String type = line.next();
						int rot = Integer.valueOf(line.next());
						
						if (type.equals("clean")) {
							if (ThreadLocalRandom.current().nextInt(1,crackOdds + 1) == crackOdds) {
								type = "cracked";
								rot = 0;
							}
						}
						
						Tile toAdd = new Tile(x,y,scale,type,rot);
						
						boolean passedFirst = false;
						while (line.hasNext()) {
							if (passedFirst) {
								toAdd.addPossibleInter(line.next());
							}
							else {
								toAdd.setInterChance(Integer.valueOf(line.next()));
							}
							
							if (!passedFirst) passedFirst = true;
						}
						
						tiles.add(toAdd);
					}
					
					if (doingDiffs) {
						Scanner line = new Scanner(lineStr);
						
						double x = Double.valueOf(line.next());
						double y = Double.valueOf(line.next());
						double w = Double.valueOf(line.next());
						double h = Double.valueOf(line.next());
						int lvl = Integer.valueOf(line.next());
						
						diffs.add(new DiffArea(x,y,w,h,lvl, true));
					}
					
					if (doingInters) {
						Scanner line = new Scanner(lineStr);
						
						double x = Double.valueOf(line.next());
						double y = Double.valueOf(line.next());
						double scale = Double.valueOf(line.next());
						double w = Double.valueOf(line.next());
						double h = Double.valueOf(line.next());
						String type = line.next();
						
						String rest = "";
						while (line.hasNext()) {
							rest += line.next() + " ";
						}
						
						Interactable toAdd = new Interactable(x,y,scale, w, h, type);
						toAdd.restOfStuff(rest);
						
						inters.add(toAdd);
					}
				}
			}
			
			for (DiffArea diff : diffs) {
			}

			spawnLocs.add(new EnemySpawner(10, -9, 5, new int[][] {{0,0}, {1,0}}, new Enemy("spurt", 1, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(50,  0, 5, new int[][] {{-1,0}, {1,0}, {0,-1}, {0,1}}, new Enemy("spurt", 3, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(25,  -14, 5, new int[][] {{0,0}}, new Enemy("puegot", 1, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(12, 12, 5, new int[][] {{0,0}}, new Enemy("sloan", 1, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(10.0, -16.0, 5, new int[][] {{0,0},{0,1}}, new Enemy("spurt", 1, 0,0,1), 60, 30));
			spawnLocs.add(new EnemySpawner(42.0, -13.0, 5, new int[][] {{0,-2},{0,2}}, new Enemy("sloan", 1, 0,0,1), 150, 15));
			spawnLocs.add(new EnemySpawner(24.0, 8.0, 5, new int[][] {{0,-1},{0,1}}, new Enemy("spurt", 1, 0,0,1), 180, 30));
			spawnLocs.add(new EnemySpawner(24.0, 14.0, 5, new int[][] {{-1,0},{1,0}}, new Enemy("spurt", 1, 0,0,1), 180, 45));
			spawnLocs.add(new EnemySpawner(29.0, 24.0, 5, new int[][] {{0,0}}, new Enemy("puegot", 2, 0,0,1), 300, 45));
			spawnLocs.add(new EnemySpawner(40.0, 19.0, 5, new int[][] {{-1,-1},{-1, 1},{1, -1},{1,1}}, new Enemy("spurt", 2, 0,0,1), 180, 30));
			spawnLocs.add(new EnemySpawner(35.0, -15.0, 5, new int[][] {{0,0}}, new Enemy("puegot", 2, 0,0,1), 120, 45));
			spawnLocs.add(new EnemySpawner(24.0, -25.0, 5, new int[][] {{-3,0}, {3,0}}, new Enemy("spurt", 2, 0,0,1), 120, 45));
			spawnLocs.add(new EnemySpawner(47.0, -27.0, 5, new int[][] {{0,0}}, new Enemy("puegot", 10, 0,0,1, "cornerPuegotBoss"), 120, 15, 1));
			spawnLocs.add(new EnemySpawner(51.0, -15.0, 5, new int[][] {{0,-3}, {0,3}}, new Enemy("spurt", 2, 0,0,1), 120, 45));
			spawnLocs.add(new EnemySpawner(45.0, 9.0, 5, new int[][] {{0,0}}, new Enemy("sloan", 3, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(55.0, 10.0, 5, new int[][] {{0,0}, {2,1}}, new Enemy("spurt", 3, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(84.0, -23.0, 5, new int[][] {{0,0}}, new Enemy("puegot", 4, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(61.0, -31.0, 5, new int[][] {{0,0}, {0,-2}, {0,-4}, {0,-6}}, new Enemy("spurt", 3, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(55.0, -23.0, 5, new int[][] {{0,0}}, new Enemy("sloan", 10, 0,0,1, "t3SloanBoss"), 120, 30, 1)); //TODO: deal with this guy
			spawnLocs.add(new EnemySpawner(84.0, -4.0, 5, new int[][] {{0,0}, {4,0}}, new Enemy("puegot", 3, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(81.0, 10.0, 5, new int[][] {{0,0}}, new Enemy("spurt", 4, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(81.0, 17.0, 5, new int[][] {{0,0}}, new Enemy("spurt", 4, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(65.0, 2.0, 5, new int[][] {{0,0}}, new Enemy("puegot", 3, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(66.0, 2.0, 5, new int[][] {{0,0}}, new Enemy("puegot", 3, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(86.0, -17.0, 5, new int[][] {{0,-4}, {0,4}}, new Enemy("sloan", 3, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(99.0, -20.0, 5, new int[][] {{0,0}}, new Enemy("puegot", 5, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(102.0, -17.0, 5, new int[][] {{0,0}}, new Enemy("puegot", 5, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(102.0, 14.0, 5, new int[][] {{0,0}, {3,0}}, new Enemy("spurt", 3, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(102.0, 5.0, 5, new int[][] {{0,0}}, new Enemy("sloan", 3, 0,0,1), 60, 15));
			spawnLocs.add(new EnemySpawner(97.0, 4.0, 5, new int[][] {{0,0}}, new Enemy("sloan", 3, 0,0,1), 60, 15));
			spawnLocs.add(new EnemySpawner(114.0, 14.0, 5, new int[][] {{0,0}}, new Enemy("spurt", 10, 0,0,1, "t3CornerSpurt"), 20, 15, 1));
			spawnLocs.add(new EnemySpawner(101.0, -5.0, 5, new int[][] {{0,0}}, new Enemy("spurt", 3, 0,0,1), 180, 30));
			spawnLocs.add(new EnemySpawner(108.0, -3.0, 5, new int[][] {{0,0}}, new Enemy("spurt", 3, 0,0,1), 180, 30));
			spawnLocs.add(new EnemySpawner(84.0, -3.0, 5, new int[][] {{-4,0}, {4,0}}, new Enemy("spurt", 3, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(79.0, -33.0, 5, new int[][] {{-4,0}, {4,0}}, new Enemy("spurt", 1, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(113.0, -29.0, 5, new int[][] {{0,0}}, new Enemy("spurt", 3, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(107.0, -21.0, 5, new int[][] {{0,0}}, new Enemy("puegot", 3, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(103.0, -25.0, 5, new int[][] {{0,0}}, new Enemy("puegot", 3, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(112.0, -12.0, 5, new int[][] {{0,0}}, new Enemy("puegot", 4, 0,0,1), 120, 30));
			spawnLocs.add(new EnemySpawner(112.0, -8.0, 5, new int[][] {{0,0}}, new Enemy("puegot", 4, 0,0,1), 120, 30));
		} catch (Exception e) {e.printStackTrace();}
	}

	/********************************************************************************
	* saveData()                                                                    *
	* saves necessary data to a save file                                           *
	*                                                                               *
	* Parameters:                                                                   *
	* String fileName                                                               *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public static void saveData(String fileName) {
		PrintWriter writer = null;
		
		try {
			writer = new PrintWriter(new File("SaveData/" + fileName + ".data"));
			writer.print("");
			player.saveStats(writer, true);
			
			writer.close();
		} catch (Exception e) {}
	}

	public static void loadMenu() {
		if (!menuLoaded) {
			menuPackSlots.clear();
			menuInvSlots.clear();
			menuCraftingSlots.clear();
			for (Item item : player.getPack()) {
				MenuSlot toAdd = new MenuSlot(item.clone());
				menuPackSlots.add(toAdd);
			}
			
			for (Item item : player.getInv()) {
				MenuSlot toAdd = new MenuSlot(item.clone());
				menuInvSlots.add(toAdd);
			}
			
			for (Item item : craftingItems) {
				MenuSlot toAdd = new MenuSlot(item.clone());
				menuCraftingSlots.add(toAdd);
			}
			
			menuLoaded = true;
		}
	}
	
	/********************************************************************************
	* exitToDesktop()                                                               *
	* run when request to close the game is called, unloads objects and saves data *
	*                                                                               *
	* Parameters:                                                                   *
	* String fileName                                                               *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public static void exitToDesktop(String fileName) {
		PrintWriter writer = null;
		
		try {
			writer = new PrintWriter(new File("SaveData/" + fileName + ".data"));
			writer.print("");
			player.saveStats(writer, false);
			
			writer.close();
		} catch (Exception e) {}
	}
}