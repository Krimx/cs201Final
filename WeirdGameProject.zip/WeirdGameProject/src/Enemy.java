import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class Enemy {
	private double x,y,w,h, bh, speed, nvx, nvy;
	private int maxHealth, health;
	private String type;
	private int level;
	private int damage;
	private double followDistance, projRange;
	
	private Hitbox hitbox;
	private Hitbox leftBox, rightBox, upBox, downBox;
	private boolean leftCol, rightCol, upCol, downCol;
	
	private String state;
	private int animation, baseAnimation;
	
	private int attackTime;
	private String tag;
	
	public Enemy(String type, int level, double xIn, double yIn, int scale) {
		this.x = xIn * scale;
		this.y = yIn * scale;
		this.type = type;
		this.level = level;
		nvx = 0;
		nvy = 0;
		baseAnimation = 0;
		
		if (this.type.equals("spurt")) {
			this.w = 4;
			this.h = 6;
			this.maxHealth = 20;
			this.speed = 0.3;
			this.damage = 10;
			this.bh = 2;
			this.followDistance = 50;
		}
		if (this.type.equals("puegot")) {
			this.w = 6;
			this.h = 4;
			this.maxHealth = 30;
			this.speed = 0;
			this.damage = 15;
			this.bh = 2;
			this.followDistance = 16;
			baseAnimation = 120;
		}
		if (this.type.equals("sloan")) {
			this.w = 6;
			this.h = 6;
			this.maxHealth = 50;
			this.speed = 0.4;
			this.damage = 20;
			this.bh = 8;
			this.followDistance = 100;
			this.projRange = 30;
			this.attackTime = 90;
		}
		
		animation = baseAnimation;
		
		this.maxHealth *= this.level;
		this.damage *= this.level;
		
		this.health = this.maxHealth;
		
		hitbox = new Hitbox(x,y,w,h);
		leftBox = new Hitbox(x - (w / 2) - 0.1,
				y - (bh / 2) + 0.1,
				0.1,
				bh - 0.2);
		
		rightBox = new Hitbox(x + (w / 2),
				y - (bh / 2) + 0.1,
				0.1,
				bh - 0.2);
		
		upBox = new Hitbox(x - (w / 2) + 0.1,
				y - (bh / 2) - 0.1,
				w - 0.2,
				0.1
				);
		
		downBox = new Hitbox(x - (w / 2) + 0.1,
				y + (bh / 2),
				w - 0.2,
				0.1
				);
		
		state = "roaming";
		this.tag = null;
	}
	
	public Enemy(String type, int level, double xIn, double yIn, int scale, String tag) {
		this(type,level,xIn,yIn,scale);
		this.tag = tag;
	}
	
	public void updateHitboxes() {
		hitbox.update(x,y,w,bh);
		
		leftBox.update(x - (w / 2) - 0.1,
				y + (h / 2),
				0.1,
				bh - 0.5);
		
		rightBox.update(x + (w / 2),
				y + (h / 2),
				0.1,
				bh - 0.5);
		
		upBox.update(x,
				y - (bh / 2) - 0.1 + (h / 2),
				w - 0.5,
				0.1
				);
		
		downBox.update(x,
				y + (bh / 2) + (h / 2),
				w - 0.5,
				0.1
				);
	}
	public void resetCol() {
		this.leftCol = false;
		this.rightCol = false;
		this.upCol = false;
		this.downCol = false;
	}
	public double distance(double x1, double y1, double x2, double y2) {
		return Math.hypot(x2 - x1, y2 - y1);
	}
	public double distance(double x1, double y1) {
		return Math.hypot(x1 - this.x, y1 - this.y);
	}
	
	/********************************************************************************
	* update()                                                                      *
	* runs every tick; updates the object                                           *
	*                                                                               *
	* Parameters:                                                                   *
	* Player player                                                                 *
	* ArrayList<Block> blocks                                                       *
	* ArrayList<Interactable> inters                                                *
	* ArrayList<Enemy> enemies                                                      *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void update(Player player, ArrayList<Block> blocks, ArrayList<Interactable> inters, ArrayList<Enemy> enemies, ArrayList<Particle> particles, ArrayList<Spell> spells, Resources recs) {
		if (animation > 0) animation--;
		if (animation == 0) {
			animation = baseAnimation;
		}
		
		double distance = distance(this.x, this.y, player.getX(), player.getY());
		
		
		double angle = getAngle(this.x, this.y, player.getX(), player.getY());
		double dx = 0,dy = 0;
		
		if (this.type.equals("spurt")) {
			if (distance <= this.followDistance) this.state = "chasing";
			else this.state = "roaming";
			
			if (this.state.equals("roaming")) {
				
			}
			if (this.state.equals("chasing")) {
				dx = this.x + (speed * Math.cos(angle)) - this.x;
				dy = this.y + (speed * Math.sin(angle)) - this.y;
				nvx = dx;
				nvy = dy;
			}

			double dxBoid = 0;
			double dyBoid = 0;
			
			for (Enemy enemy : enemies) {
				if (!enemy.equals(this)) {
					double dis = distance(enemy.getX(), enemy.getY());
					if (dis <= 5) {
						double dir = getAngle(this.x, this.y, enemy.getX(), enemy.getY());
						dxBoid = (this.x + (dis * Math.cos(dir)) - this.x) / 2;
						dyBoid = (this.x + (dis * Math.sin(dir)) - this.x) / 2;
					}
				}
			}
			
			for (double i = 0; i < Math.abs(dx); i += 0.1) {
				updateHitboxes();
				resetCol();
				collision(blocks, inters);
				
				
				if (dx - dxBoid > 0 && !rightCol) x += 0.1;
				if (dx - dxBoid < 0 && !leftCol) x -= 0.1;
				
				x = round(x);
			}
			
			for (double i = 0; i < Math.abs(dy); i += 0.1) {
				updateHitboxes();
				resetCol();
				collision(blocks, inters);
				
				if (dy - dyBoid > 0 && !downCol) y += 0.1;
				if (dy - dyBoid < 0 && !upCol) y -= 0.1;
				
				y = round(y);
			}
		}
		else if (this.type.equals("puegot")) {
			if (distance <= this.followDistance) {
				if (animation == 120) {
					particles.add(new Particle(this.x, this.y, "rumble", null, recs));
					player.damage(this.damage);
				}
			}
			
		}
		else if (this.type.equals("sloan")) {
			if (distance <= this.projRange) this.state = "attacking";
			else if (distance <= this.followDistance) this.state = "chasing";
			else this.state = "roaming";
			
			if (this.state.equals("roaming")) {
				
			}
			if (this.state.equals("chasing")) {
				dx = this.x + (speed * Math.cos(angle)) - this.x;
				dy = this.y + (speed * Math.sin(angle)) - this.y;
				nvx = dx;
				nvy = dy;
			}
			if (this.state.equals("attacking")) {
				sloanProj(spells, player);
			}

			double dxBoid = 0;
			double dyBoid = 0;
			
			for (Enemy enemy : enemies) {
				if (!enemy.equals(this)) {
					double dis = distance(enemy.getX(), enemy.getY());
					if (dis <= 5) {
						double dir = getAngle(this.x, this.y, enemy.getX(), enemy.getY());
						dxBoid = (this.x + (dis * Math.cos(dir)) - this.x) / 2;
						dyBoid = (this.x + (dis * Math.sin(dir)) - this.x) / 2;
					}
				}
			}
			
			for (double i = 0; i < Math.abs(dx); i += 0.1) {
				updateHitboxes();
				resetCol();
				collision(blocks, inters);
				
				
				if (dx - dxBoid > 0 && !rightCol) x += 0.1;
				if (dx - dxBoid < 0 && !leftCol) x -= 0.1;
				
				x = round(x);
			}
			
			for (double i = 0; i < Math.abs(dy); i += 0.1) {
				updateHitboxes();
				resetCol();
				collision(blocks, inters);
				
				if (dy - dyBoid > 0 && !downCol) y += 0.1;
				if (dy - dyBoid < 0 && !upCol) y -= 0.1;
				
				y = round(y);
			}
			
			
		}
		else {
			
		}
	}
	
	public void sloanProj(ArrayList<Spell> spells, Player player) {
		if (this.attackTime > 0) {
			this.attackTime--;
		}
		if (this.attackTime == 0) {
			this.attackTime = 150;
		}
		
		if (this.attackTime == 30) {
			Spell toAdd = new Spell("lob", this.x, this.y, null, player, 0,0, this.level);
			spells.add(toAdd);
		}
	}
	
	public void collision(ArrayList<Block> blocks, ArrayList<Interactable> inters) {
		for (Block block : blocks) {
			if (this.rightBox.isColliding(block.getHitbox())) rightCol = true;
			if (this.leftBox.isColliding(block.getHitbox())) leftCol = true;
			if (this.upBox.isColliding(block.getHitbox())) upCol = true;
			if (this.downBox.isColliding(block.getHitbox())) downCol = true;
		}
		
		for (Interactable inter : inters) {
			if (this.rightBox.isColliding(inter.getHitbox()) && inter.getCollidable()) rightCol = true;
			if (this.leftBox.isColliding(inter.getHitbox()) && inter.getCollidable()) leftCol = true;
			if (this.upBox.isColliding(inter.getHitbox()) && inter.getCollidable()) upCol = true;
			if (this.downBox.isColliding(inter.getHitbox()) && inter.getCollidable()) downCol = true;
		}
	}
	
	/********************************************************************************
	* render()                                                                      *
	* renders to jpanel                                                             *
	*                                                                               *
	* Parameters:                                                                   *
	* Graphics g                                                                    *
	* int scrWidth                                                                  *
	* int scrHeight                                                                 *
	* int mult                                                                      *
	* Camera camera                                                                 *
	* Resources recs                                                                *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void render(Graphics g, int scrWidth, int scrHeight, int mult, Camera camera, Resources recs) {
		double scale = (double) (((double) (scrWidth) / (double) (mult)) * 10);
		
		int xOffset = scrWidth / 2;
		int yOffset = scrHeight / 2;
		
		int renderW = (int) (w * scale);
		int renderH = (int) (h * scale);
		
		int renderX = (int) ((x * scale) + xOffset - camera.getX() - ((double) renderW / 2.0));
		int renderY = (int) ((y * scale) + yOffset - camera.getY() - ((double) renderH / 2.0));
		
		
		String facing = "down";
		if (Math.abs(nvx) > Math.abs(nvy)) {
			if (nvx < 0) {
				facing = "left";
			}
			else {
				facing = "right";
			}
		}
		else {
			if (nvy > 0) {
				facing = "down";
			}
			else {
				facing = "up";
			}
		}

		BufferedImage toRender = null;
		if (facing.equals("right")) {
			if (this.type.equals("spurt")) toRender = recs.spurtRight;
			if (this.type.equals("sloan")) toRender = recs.sloanFront;
		}
		if (facing.equals("left")) {
			if (this.type.equals("spurt")) toRender = recs.spurtLeft;
			if (this.type.equals("sloan")) toRender = recs.sloanFront;
		}
		if (facing.equals("up")) {
			if (this.type.equals("spurt")) toRender = recs.spurtBack;
			if (this.type.equals("sloan")) toRender = recs.sloanFront;
		}
		if (facing.equals("down")) {
			if (this.type.equals("spurt")) toRender = recs.spurtFront;
			if (this.type.equals("sloan")) toRender = recs.sloanFront;
		}
		
		if (this.type.equals("puegot")) {
			if (animation > 60) toRender = recs.puegotSquish;
			else toRender = recs.puegotStretch;
		}
		
		
		g.drawImage(toRender, renderX, renderY, (int) renderW, (int) renderH, null);

		
		if (this.health < this.maxHealth) {
			int barLength = 50;
			int statBarLength = barLength - 4;
			
			g.setColor(Color.gray);
			g.fillRect(renderX, renderY - 30, barLength, 20);
			g.setColor(Color.black);
			g.fillRect(renderX + 3, renderY - 30 + 3, barLength - 6, 20 - 6);
			
			g.setColor(new Color(247, 74, 74));
			int healthLength = (int) ((double)statBarLength * ((double) this.health / (double) this.maxHealth));
			g.fillRect(renderX + 3, renderY - 30 + 3, healthLength, 7);
			g.setColor(new Color(200, 74, 74));
			g.fillRect(renderX + 3, renderY - 30 + 3 + 7, healthLength, 7);
		}
	}
	
	public double getAngle(double x1, double y1, double x2, double y2) {
		double form1 = (double) (x2 - x1);
		double form2 = (double) (y2 - y1);
		double angle = Math.atan2(form2, form1);
		
		return angle;
	}
	public double round(double in) {
		return Math.round(in*100)/100.0;
	}
	
	/********************************************************************************
	* dropLoot()                                                                    *
	* drops items when die                                                          *
	*                                                                               *
	* Parameters:                                                                   *
	* ArrayList<Item> items                                                         *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void dropLoot(ArrayList<Item> items) {
		if (this.type.equals("spurt")) {
			Item toAdd = new Item(this.x, this.y, "heal");
			toAdd.setHealAmount(2 * this.level);
			items.add(toAdd);
		}
		else if (this.type.equals("puegot")) {
			for (int i = 0; i < 2; i++) {
				Item toAdd = new Item(this.x, this.y, "heal");
				toAdd.setHealAmount(this.level);
				items.add(toAdd);
			}
		}
		
		int dropEssence = ThreadLocalRandom.current().nextInt(0,3);
		if (dropEssence == 0) {
			int amount = ThreadLocalRandom.current().nextInt(0,3);
			for (int i = 0; i < amount + 1; i++) {
				double xOffset = ThreadLocalRandom.current().nextDouble(-1,2);
				double yOffset = ThreadLocalRandom.current().nextDouble(-1,2);
				Item toAdd = new Item(this.x + xOffset, this.y + yOffset, "essence");
				items.add(toAdd);
			}
		}
		if (this.tag != null) {
			System.out.println("Passed 1");
			if (this.tag.equals("cornerPuegotBoss")) {
				double xOffset = ThreadLocalRandom.current().nextDouble(-1,2);
				double yOffset = ThreadLocalRandom.current().nextDouble(-1,2);
				items.add(new Item(this.x + xOffset, this.y + yOffset, "ooze"));
			}
			if (this.tag.equals("t3SloanBoss")) {
				double xOffset = ThreadLocalRandom.current().nextDouble(-1,2);
				double yOffset = ThreadLocalRandom.current().nextDouble(-1,2);
				items.add(new Item(this.x + xOffset, this.y + yOffset, "healthUp3"));
				
				xOffset = ThreadLocalRandom.current().nextDouble(-1,2);
				yOffset = ThreadLocalRandom.current().nextDouble(-1,2);
				items.add(new Item(this.x + xOffset, this.y + yOffset, "damageUp3"));
				
				xOffset = ThreadLocalRandom.current().nextDouble(-1,2);
				yOffset = ThreadLocalRandom.current().nextDouble(-1,2);
				items.add(new Item(this.x + xOffset, this.y + yOffset, "manaUp3"));
			}
			if (this.tag.equals("t3CornerSpurt")) {
				double xOffset = ThreadLocalRandom.current().nextDouble(-1,2);
				double yOffset = ThreadLocalRandom.current().nextDouble(-1,2);
				items.add(new Item(this.x + xOffset, this.y + yOffset, "healthUp4"));
			}
		}
		
	}
	public String getType() {return this.type;}
	public Hitbox getHitbox() {return this.hitbox;}
	public int getHealth() {return this.health;}
	public int getDamage() {return this.damage;}
	public double getX() {return this.x;}
	public double getY() {return this.y;}
	public int getLevel() {return this.level;}
	public String getTag() {return this.tag;}
	
	public void damage(int damage) {this.health -= damage;}
}
