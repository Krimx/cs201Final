import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class Block {
	private double x, y, w,h, scale;
	private String type;
	private Hitbox hitbox;
	private int rot;
	
	public Block(double x, double y, double scale, String type, int rot) {
		this.x = x * scale;
		this.y = y * scale;
		this.w = scale;
		this.h = scale;
		
		this.scale = scale;
		
		this.type = type;
		
		this.hitbox = new Hitbox(this.x, this.y , this.w, this.h);
		
		this.rot = rot;
	}
	
	/********************************************************************************
	* render()                                                                      *
	* renders to jpanel                                                             *
	*                                                                               *
	* Parameters:                                                                   *
	* Graphics g                                                                    *
	* int scrWidth                                                                  *
	* int scrHeight                                                                 *
	* int mult                                                                      *
	* Camera camera                                                                 *
	* Resources recs                                                                *
	*                                                                               *
	* Return Type: none                                                             *
	********************************************************************************/
	public void render(Graphics g, int scrWidth, int scrHeight, int mult, Camera camera, Resources recs) {
		double scale = (double) (((double) (scrWidth) / (double) (mult)) * 10);
		
		int xOffset = scrWidth / 2;
		int yOffset = scrHeight / 2;
		
		int renderW = (int) (w * scale);
		int renderH = (int) (h * scale);
		
		int renderX = (int) ((x * scale) + xOffset - camera.getX() - ((double) renderW / 2.0));
		int renderY = (int) ((y * scale) + yOffset - camera.getY() - ((double) renderH / 2.0));
		
		boolean inFrame = false;
		if (renderX < scrWidth &&
			renderX + renderW > 0 &&
			renderY < scrHeight &&
			renderY + renderH > 0)
		{
			inFrame = true;
		}
		
		if (inFrame) {
			BufferedImage toRender = null;
			boolean doAO = false;
			
			if (this.type.equals("solo")) toRender = recs.soloBlock;
			if (this.type.equals("corner")) toRender = recs.cornerBlock;
			if (this.type.equals("edge")) toRender = recs.edgeBlock;
			if (this.type.equals("longCorner")) toRender = recs.longCornerBlock;
			if (this.type.equals("longEdge")) toRender = recs.longEdgeBlock;
			if (this.type.equals("corner2")) toRender = recs.longCorner2;
			
			boolean needRot = true;
			
			if (this.type.equals("longCorner")) {
				if (rot == 2) {
					toRender = recs.outCornerLeft;
					needRot = false;
				}
				if (rot == 3) {
					toRender = recs.outCornerRight;
					needRot = false;
				}
			}
			if (this.type.equals("longEdge") && rot == 3) {
				toRender = recs.topEdge;
				needRot = false;
				doAO = true;
			}
			if (this.type.equals("corner2")) {
				if (rot == 2) {
					toRender = recs.inCornerRight;
					needRot = false;
					doAO = true;
				}
				if (rot == 3) {
					toRender = recs.inCornerLeft;
					needRot = false;
					doAO = true;
				}
			}
			
			Graphics2D g2d = (Graphics2D) (g);
			
			if (needRot) g2d.rotate(Math.toRadians(rot * 90), renderX + (renderW / 2), renderY + (renderH / 2));
			g2d.drawImage(toRender, renderX, renderY, renderW, renderH, null);
			if (needRot) g2d.rotate(Math.toRadians(-rot * 90), renderX + (renderW / 2), renderY + (renderH / 2));
			if (doAO) {
				g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
				g.drawImage(recs.AOSprite, renderX, renderY + renderH, renderW, renderH / 8, null);
				g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
			}
		}
	}
	
	public Hitbox getHitbox() {return this.hitbox;}
	public double getX() {return this.x / this.scale;}
	public double getY() {return this.y / this.scale;}
	public double getScale() {return this.scale;}
	public String getType() {return this.type;}
	public int getRot() {return this.rot;}
}
